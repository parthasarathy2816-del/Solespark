"""List products that still use a 'Sample visual' instead of a real photo.  Run: python tools/check_images.py"""
import sys
from pathlib import Path

sys.path.insert(0, str(Path(__file__).resolve().parent.parent))

from components.product_card import has_real_photo  # noqa: E402
from services.product_data import load_catalogue  # noqa: E402

cat = load_catalogue()
missing = [r for _, r in cat.products.iterrows() if not has_real_photo(r["id"])]
print(f"{len(cat.products) - len(missing)} of {len(cat.products)} products have a real photo.")
for r in missing:
    print(f"  {r['id']}  {r['name']}  ({r['subcategory']})")
