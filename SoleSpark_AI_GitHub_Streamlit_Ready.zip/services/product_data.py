"""Product + variant data model. A product is only available when one of its variants has stock.

All data is fictional demo data (stock is simulated)."""
from __future__ import annotations

from dataclasses import dataclass, field
from pathlib import Path

import pandas as pd

ROOT = Path(__file__).resolve().parent.parent
PRODUCT_FILE = ROOT / "data" / "products.csv"
VARIANT_FILE = ROOT / "data" / "product_variants.csv"

COLUMNS = ["id", "name", "brand", "category", "subcategory", "price", "styles", "occasions", "colors",
           "materials", "size_type", "fit", "vibe", "description", "care", "rating", "trend_score",
           "new_rank", "image"]
LIST_COLS = ["styles", "occasions", "colors", "materials"]
TEXT_COLS = ["name", "brand", "category", "subcategory", "size_type", "fit", "vibe", "description", "care", "image"]
NO_SIZE_TYPES = {"", "none", "free"}


def _split(value) -> list:
    if value is None or (isinstance(value, float) and pd.isna(value)):
        return []
    if isinstance(value, (list, tuple)):
        return list(value)
    return [x.strip() for x in str(value).split("|") if x.strip()]


def clean_products(df: pd.DataFrame) -> pd.DataFrame:
    """Guarantee every column exists and missing optional values are safe (empty list / empty text / 0)."""
    df = df.copy()
    for col in COLUMNS:
        if col not in df.columns:
            df[col] = None
    for col in LIST_COLS:
        df[col] = df[col].apply(_split)
    df["price"] = pd.to_numeric(df["price"], errors="coerce")
    df = df.dropna(subset=["id", "name", "price"])
    df = df[df["price"] > 0]
    for col in ("rating", "trend_score", "new_rank"):
        df[col] = pd.to_numeric(df[col], errors="coerce").fillna(0)
    for col in TEXT_COLS:
        df[col] = df[col].fillna("").astype(str)
    df["id"] = df["id"].astype(str)
    return df.drop_duplicates("id")[COLUMNS].reset_index(drop=True)


def clean_variants(df: pd.DataFrame) -> pd.DataFrame:
    cols = ["variant_id", "product_id", "colour", "size", "stock"]
    df = df.copy()
    for c in cols:
        if c not in df.columns:
            df[c] = None
    df["stock"] = pd.to_numeric(df["stock"], errors="coerce").fillna(0).astype(int).clip(lower=0)
    for c in ("product_id", "colour", "size"):
        df[c] = df[c].fillna("").astype(str)
    return df[cols].reset_index(drop=True)


@dataclass
class Catalogue:
    products: pd.DataFrame
    variants: pd.DataFrame
    _index: dict = field(default_factory=dict, repr=False)

    def __post_init__(self):
        self.products = clean_products(self.products)
        self.variants = clean_variants(self.variants)
        known = set(self.products["id"])
        self.variants = self.variants[self.variants["product_id"].isin(known)]
        self._index = {}
        for r in self.variants.itertuples(index=False):
            self._index.setdefault(r.product_id, []).append((r.colour, r.size, int(r.stock)))

    # --- lookups -------------------------------------------------------------------------------
    @property
    def empty(self) -> bool:
        return self.products.empty

    def product(self, pid: str):
        m = self.products[self.products["id"] == pid]
        return None if m.empty else m.iloc[0]

    def rows(self, ids) -> list:
        return [p for p in (self.product(i) for i in ids) if p is not None]

    def variants_of(self, pid: str) -> list:
        return self._index.get(pid, [])

    def stock_of(self, pid: str, colour: str, size: str) -> int:
        return sum(s for c, z, s in self.variants_of(pid) if c == colour and z == size)

    def colours_in_stock(self, pid: str, size: str | None = None) -> list:
        out = []
        for c, z, s in self.variants_of(pid):
            if s > 0 and (size is None or z == size) and c not in out:
                out.append(c)
        return out

    def sizes_in_stock(self, pid: str, colour: str | None = None) -> list:
        out = []
        for c, z, s in self.variants_of(pid):
            if s > 0 and (colour is None or c == colour) and z not in out:
                out.append(z)
        return out

    def is_available(self, pid: str) -> bool:
        return any(s > 0 for _, _, s in self.variants_of(pid))

    def eligible_variants(self, pid: str, size_type: str = "", sizes: dict | None = None,
                          excluded_colors=(), colors=()) -> list:
        """In-stock (colour, size) pairs that respect the user's size and colour constraints."""
        want = (sizes or {}).get(size_type) if size_type not in NO_SIZE_TYPES else None
        out = []
        for c, z, s in self.variants_of(pid):
            if s <= 0 or c in excluded_colors or (colors and c not in colors):
                continue
            if want and z != str(want):
                continue
            out.append((c, z))
        return out


def load_catalogue(product_path: Path | str = PRODUCT_FILE, variant_path: Path | str = VARIANT_FILE) -> Catalogue:
    """A missing or empty file gives an empty catalogue instead of crashing."""
    try:
        prods = pd.read_csv(product_path, dtype=str)
    except (FileNotFoundError, pd.errors.EmptyDataError):
        prods = pd.DataFrame()
    try:
        vars_ = pd.read_csv(variant_path, dtype=str)
    except (FileNotFoundError, pd.errors.EmptyDataError):
        vars_ = pd.DataFrame()
    return Catalogue(prods, vars_)


def make_catalogue(product_rows: list, variant_rows: list) -> Catalogue:
    """Handy for tests: build a catalogue from lists of dicts."""
    return Catalogue(pd.DataFrame(product_rows), pd.DataFrame(variant_rows))


def validate_catalogue(cat: Catalogue) -> list:
    """Return a list of data problems (empty list = consistent)."""
    problems = []
    raw = cat.products
    if raw["id"].duplicated().any():
        problems.append("duplicate product ids")
    for pid in raw["id"]:
        if not cat.variants_of(pid):
            problems.append(f"{pid} has no variants")
    return problems


def filter_products(cat: Catalogue, categories=(), subcategories=(), price_range=None, sizes: dict | None = None,
                    colors=(), excluded_colors=(), materials=(), excluded_materials=(), styles=(),
                    occasions=(), available_only: bool = True) -> pd.DataFrame:
    """One filter used by the shop, the recommender and the stylist, so they always agree.

    Colour and size are checked on VARIANTS: a shirt is kept only if one colour/size variant that is in stock
    satisfies every colour and size constraint at the same time. Price limits are inclusive."""
    df = cat.products
    if df.empty:
        return df
    keep = []
    for r in df.itertuples(index=False):
        if categories and r.category not in categories:
            continue
        if subcategories and r.subcategory not in subcategories:
            continue
        if price_range and not (price_range[0] <= r.price <= price_range[1]):
            continue
        if materials and not set(r.materials) & set(materials):
            continue
        if excluded_materials and set(r.materials) & set(excluded_materials):
            continue
        if styles and not set(r.styles) & set(styles):
            continue
        if occasions and not set(r.occasions) & set(occasions):
            continue
        if available_only or sizes or colors or excluded_colors:
            if not cat.eligible_variants(r.id, r.size_type, sizes, excluded_colors, colors):
                continue
        keep.append(r.id)
    return df[df["id"].isin(keep)]
