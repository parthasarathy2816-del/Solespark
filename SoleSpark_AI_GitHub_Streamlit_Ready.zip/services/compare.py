"""Category-aware comparison: only attributes that make sense for the chosen items are compared."""
from __future__ import annotations

from services.product_data import NO_SIZE_TYPES, Catalogue

MAX_COMPARE = 3


def compare_rows(cat: Catalogue, ids: list):
    """Return (rows, note). rows = [(attribute, [value per product])]."""
    items = cat.rows(ids[:MAX_COMPARE])
    if not items:
        return [], "Pick up to three products to compare."
    rows = [("Category", [f"{r['category']} / {r['subcategory']}" for r in items]),
            ("Brand", [r["brand"] for r in items]),
            ("Price (Rs)", [f"{int(r['price']):,}" for r in items]),
            ("Material", [", ".join(r["materials"]) or "-" for r in items]),
            ("Styles", [", ".join(r["styles"]) or "-" for r in items]),
            ("Occasions", [", ".join(r["occasions"]) or "-" for r in items]),
            ("Colours in stock", [", ".join(cat.colours_in_stock(r["id"])) or "Out of stock" for r in items]),
            ("Rating (sample)", [str(r["rating"]) for r in items])]
    note = ""
    types = {r["size_type"] for r in items}
    if len(types) == 1 and not types & NO_SIZE_TYPES:
        rows.append(("Sizes in stock", [", ".join(cat.sizes_in_stock(r["id"])) or "None" for r in items]))
        if all(r["fit"] for r in items):
            rows.append(("Fit", [r["fit"] for r in items]))
    elif len(types) > 1:
        note = "These items use different sizing systems, so sizes are not compared."
    return rows, note
