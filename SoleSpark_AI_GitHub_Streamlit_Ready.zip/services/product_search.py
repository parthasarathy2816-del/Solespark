"""Unified search across every category, plus type-ahead suggestions.

Rule-based keyword parsing (no AI model, no external API)."""
from __future__ import annotations

import re
from dataclasses import dataclass, field

import pandas as pd

from services.glyphs import COLOUR_HEX
from services.product_data import Catalogue

SYNONYMS = {
    "tee": "T-shirts", "tees": "T-shirts", "tshirt": "T-shirts", "tshirts": "T-shirts", "shirt": "Shirts",
    "pants": "Trousers", "chinos": "Trousers", "denim": "Jeans", "gown": "Ethnic wear", "kurta": "Ethnic wear",
    "saree": "Ethnic wear", "sherwani": "Ethnic wear", "sunglasses": "Eyewear", "glasses": "Eyewear",
    "shades": "Eyewear", "sneaker": "Sneakers", "trainers": "Running shoes", "sandal": "Sandals", "heel": "Heels",
    "loafer": "Loafers", "boot": "Boots", "backpack": "Backpacks", "handbag": "Handbags", "purse": "Handbags",
    "clutch": "Clutches", "necklace": "Necklaces", "ring": "Rings", "earring": "Earrings", "bracelet": "Bracelets",
    "watch": "Watches", "belt": "Belts", "cap": "Caps", "hat": "Hats", "scarf": "Scarves", "wallet": "Wallets",
    "jacket": "Jackets", "hoodie": "Hoodies", "coat": "Coats", "dress": "Dresses", "skirt": "Skirts", "tote": "Totes",
}
CATEGORY_WORDS = {"shoes": "Footwear", "footwear": "Footwear", "clothes": "Clothing", "clothing": "Clothing",
                  "bags": "Bags", "jewellery": "Jewellery", "jewelry": "Jewellery", "accessories": "Accessories"}
STOP = {"a", "an", "the", "for", "in", "with", "and", "me", "show", "find", "i", "want", "need", "some", "good",
        "best", "rs", "inr", "under", "below", "over", "above", "less", "more", "than", "to", "of"}


@dataclass
class SearchResult:
    products: pd.DataFrame
    parsed: dict = field(default_factory=dict)
    message: str = ""


def _price(text: str):
    """Understands 'under 3k', 'below 3000', 'over 5,000', 'above 2k'."""
    mx = mn = None
    for word, num, k in re.findall(r"(under|below|less than|over|above|more than)\s*(?:rs\.?|inr)?\s*([\d,]+(?:\.\d+)?)\s*(k)?", text):
        val = float(num.replace(",", "")) * (1000 if k else 1)
        if word in ("under", "below", "less than"):
            mx = val
        else:
            mn = val
    return mn, mx


def parse_query(cat: Catalogue, query: str) -> dict:
    q = query.lower().strip()
    mn, mx = _price(q)
    q = re.sub(r"(under|below|less than|over|above|more than)\s*(?:rs\.?|inr)?\s*[\d,.]+\s*k?", " ", q)
    words = re.findall(r"[a-z\-']+", q)
    df = cat.products
    subs = {s.lower(): s for s in df["subcategory"].unique()}
    vocab = {"styles": {s.lower(): s for x in df["styles"] for s in x}, "occasions": {s.lower(): s for x in df["occasions"] for s in x},
             "materials": {s.lower(): s for x in df["materials"] for s in x}}
    out = {"min_price": mn, "max_price": mx, "categories": [], "subcategories": [], "colors": [], "styles": [],
           "occasions": [], "materials": [], "words": []}
    for w in words:
        if w in STOP:
            continue
        if w in CATEGORY_WORDS:
            out["categories"].append(CATEGORY_WORDS[w])
        elif w in SYNONYMS or w in subs:
            out["subcategories"].append(SYNONYMS.get(w, subs.get(w)))
        elif w.capitalize() in COLOUR_HEX:
            out["colors"].append(w.capitalize())
        elif any(w in v for v in vocab.values()):
            for key, v in vocab.items():
                if w in v:
                    out[key].append(v[w])
        else:
            out["words"].append(w)
    return out


def search(cat: Catalogue, query: str, available_only: bool = True) -> SearchResult:
    if not query or not query.strip():
        return SearchResult(cat.products.iloc[0:0], {}, "Type something like 'black leather loafers under 5k'.")
    parsed = parse_query(cat, query)
    keep = []
    for r in cat.products.itertuples(index=False):
        if parsed["categories"] and r.category not in parsed["categories"]:
            continue
        if parsed["subcategories"] and r.subcategory not in parsed["subcategories"]:
            continue
        if parsed["max_price"] is not None and r.price > parsed["max_price"]:
            continue
        if parsed["min_price"] is not None and r.price < parsed["min_price"]:
            continue
        if parsed["colors"]:
            ok = (bool(cat.eligible_variants(r.id, colors=parsed["colors"])) if available_only
                  else bool(set(r.colors) & set(parsed["colors"])))
            if not ok:
                continue
        if available_only and not cat.is_available(r.id):
            continue
        if any(parsed[k] and not set(parsed[k]) & set(getattr(r, k)) for k in ("styles", "occasions", "materials")):
            continue
        hay = f"{r.name} {r.brand} {r.subcategory} {' '.join(r.materials)}".lower()
        if any(w.rstrip("s") not in hay for w in parsed["words"]):
            continue
        keep.append(r.id)
    res = cat.products[cat.products["id"].isin(keep)]
    msg = "" if len(res) else f"No products match '{query.strip()}'. Try fewer words or a higher price."
    return SearchResult(res, parsed, msg)


def suggestions(cat: Catalogue, prefix: str, n: int = 6) -> list:
    """Type-ahead: subcategories, product names and brands that start with or contain the typed text."""
    p = prefix.lower().strip()
    if len(p) < 2 or cat.empty:
        return []
    pool = list(cat.products["subcategory"].unique()) + list(cat.products["name"]) + list(cat.products["brand"].unique())
    starts = [s for s in dict.fromkeys(pool) if s.lower().startswith(p)]
    contains = [s for s in dict.fromkeys(pool) if p in s.lower() and s not in starts]
    return (starts + contains)[:n]
