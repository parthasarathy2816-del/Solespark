"""Two-stage, explainable recommender (rule-based, NOT a trained AI model).

Stage A: hard filters (category, budget, availability, size, excluded colours/materials).
Stage B: weighted preference scoring, normalised over the factors that apply to each product."""
from __future__ import annotations

from dataclasses import dataclass, field, replace

from services.product_data import Catalogue, filter_products

# Configurable weights (they add up to 100).
WEIGHTS = {"style": 22, "occasion": 18, "budget": 14, "color": 12, "material": 8, "vibe": 8, "fit": 6, "likes": 12}
BUDGET_MAX = 50000
DISLIKE_PENALTY = 15
OWNED_PENALTY = 12


@dataclass
class Preferences:
    categories: list = field(default_factory=list)
    subcategories: list = field(default_factory=list)
    styles: list = field(default_factory=list)
    occasions: list = field(default_factory=list)
    colors: list = field(default_factory=list)
    excluded_colors: list = field(default_factory=list)
    materials: list = field(default_factory=list)
    excluded_materials: list = field(default_factory=list)
    budget_min: int = 0
    budget_max: int = 15000
    sizes: dict = field(default_factory=dict)  # e.g. {"shoe": "8", "apparel": "M"}
    fits: list = field(default_factory=list)
    vibes: list = field(default_factory=list)  # Trending / Timeless / Understated / Bold
    liked_ids: list = field(default_factory=list)
    disliked_ids: list = field(default_factory=list)
    owned_subcategories: list = field(default_factory=list)  # types the user already owns (ranked lower)


@dataclass
class Rec:
    id: str
    score: int
    reasons: list


@dataclass
class Relaxation:
    key: str
    label: str
    count: int


@dataclass
class RecResult:
    items: list = field(default_factory=list)
    message: str = ""
    errors: list = field(default_factory=list)
    relaxations: list = field(default_factory=list)


def check_weights(weights: dict = WEIGHTS) -> bool:
    return sum(weights.values()) == 100


def validate_preferences(p: Preferences) -> list:
    errors = []
    if p.budget_min < 0:
        errors.append("Minimum budget cannot be negative.")
    if p.budget_max <= 0 or p.budget_max > BUDGET_MAX:
        errors.append(f"Maximum budget must be between Rs 1 and Rs {BUDGET_MAX:,}.")
    if p.budget_min > p.budget_max:
        errors.append("Minimum budget cannot be higher than the maximum budget.")
    if set(p.colors) & set(p.excluded_colors):
        errors.append("A colour cannot be both preferred and excluded.")
    if set(p.materials) & set(p.excluded_materials):
        errors.append("A material cannot be both preferred and excluded.")
    return errors


def apply_relax(p: Preferences, keys) -> Preferences:
    """Explicit, user-chosen relaxations. Nothing is ever relaxed silently."""
    q = replace(p)
    if "size" in keys:
        q.sizes = {}
    if "budget" in keys:
        q.budget_max = min(int(p.budget_max * 1.25), BUDGET_MAX)
    if "colors" in keys:
        q.excluded_colors = []
    if "materials" in keys:
        q.excluded_materials = []
    return q


def hard_filter(cat: Catalogue, p: Preferences):
    return filter_products(cat, p.categories, p.subcategories, (p.budget_min, p.budget_max), p.sizes, (),
                           p.excluded_colors, (), p.excluded_materials, (), (), available_only=True)


def _tokens(row) -> set:
    return set(row["styles"]) | set(row["occasions"]) | set(row["materials"]) | {row["subcategory"]}


def _similarity(row, others) -> float:
    a = _tokens(row)
    best = 0.0
    for o in others:
        b = _tokens(o)
        if a | b:
            best = max(best, len(a & b) / len(a | b))
    return best


def _ratio(wanted: list, have: list):
    return None if not wanted else (len(set(wanted) & set(have)) / len(set(wanted)))


def score_product(cat: Catalogue, row, p: Preferences, weights: dict = WEIGHTS):
    """Return (0-100 score, reasons). Factors the user did not state are left out, not guessed."""
    parts, why = [], []

    def add(key, value):
        if value is not None:
            parts.append((weights[key], max(0.0, min(1.0, value))))

    s = _ratio(p.styles, row["styles"])
    add("style", s)
    if s:
        why.append("Matches your " + ", ".join(sorted(set(p.styles) & set(row["styles"]))) + " style")
    o = _ratio(p.occasions, row["occasions"])
    add("occasion", o)
    if o:
        why.append("Works for " + ", ".join(sorted(set(p.occasions) & set(row["occasions"]))).lower())
    span = max(p.budget_max - p.budget_min, 1)
    target = p.budget_min + 0.6 * span
    b = 1 - abs(row["price"] - target) / span
    add("budget", max(0.4, b) if p.budget_min <= row["price"] <= p.budget_max else 0.0)
    if p.budget_min <= row["price"] <= p.budget_max:
        why.append(f"Fits your budget (Rs {int(row['price']):,})")
    if p.colors:
        have = [c for c, _ in cat.eligible_variants(row["id"], row["size_type"], p.sizes, p.excluded_colors, p.colors)]
        add("color", 1.0 if have else 0.0)
        if have:
            why.append(f"Available in {have[0]}, a colour you like")
    if p.materials:
        m = _ratio(p.materials, row["materials"])
        add("material", m)
        if m:
            why.append("Made from " + row["materials"][0].lower())
    if p.vibes:
        hit = row["vibe"] in p.vibes
        add("vibe", (0.6 + 0.4 * row["trend_score"] / 100) if hit and row["vibe"] == "Trending" else (1.0 if hit else 0.0))
        if hit:
            why.append(f"A {row['vibe'].lower()} pick")
    if p.fits and row["fit"]:
        f = 1.0 if row["fit"] in p.fits else 0.0
        add("fit", f)
        if f:
            why.append(f"{row['fit']} fit as you prefer")
    liked = cat.rows(p.liked_ids)
    if liked:
        sim = _similarity(row, liked)
        add("likes", min(1.0, sim * 1.6))
        if sim >= 0.4:
            why.append("Similar to items you liked")
    total_w = sum(w for w, _ in parts) or 1
    score = 100 * sum(w * v for w, v in parts) / total_w
    disliked = cat.rows(p.disliked_ids)
    if disliked and _similarity(row, disliked) >= 0.6:
        score -= DISLIKE_PENALTY
    if row["subcategory"] in p.owned_subcategories:
        score -= OWNED_PENALTY
        why.append("You already own this type, so it ranks lower")
    return int(round(max(0, min(100, score)))), why


def recommend(cat: Catalogue, p: Preferences, weights: dict = WEIGHTS, top_n: int = 12, relax=()) -> RecResult:
    errors = validate_preferences(p)
    if errors:
        return RecResult(message=" ".join(errors), errors=errors)
    if cat.empty:
        return RecResult(message="The product catalogue is empty, so there is nothing to recommend yet.")
    q = apply_relax(p, relax)
    pool = hard_filter(cat, q)
    liked = set(p.liked_ids)
    recs = []
    for _, row in pool.iterrows():
        if row["id"] in liked:
            continue
        score, why = score_product(cat, row, q, weights)
        recs.append((score, row["trend_score"], Rec(row["id"], score, why)))
    recs.sort(key=lambda t: (-t[0], -t[1], t[2].id))
    items = [r for _, _, r in recs[:top_n]]
    if items:
        return RecResult(items=items)
    options = suggest_relaxations(cat, p)
    msg = "No available product satisfies all your requirements."
    if options:
        msg += " You can relax: " + ", ".join(f"{o.label} ({o.count} products)" for o in options) + "."
    else:
        msg += " Try choosing more categories or a wider budget."
    return RecResult(message=msg, relaxations=options)


def suggest_relaxations(cat: Catalogue, p: Preferences) -> list:
    labels = {"size": "ignore size", "budget": "raise maximum budget by 25%", "colors": "allow excluded colours",
              "materials": "allow excluded materials"}
    active = {"size": bool(p.sizes), "budget": True, "colors": bool(p.excluded_colors),
              "materials": bool(p.excluded_materials)}
    out = []
    for key, label in labels.items():
        if active[key]:
            n = len(hard_filter(cat, apply_relax(p, [key])))
            if n:
                out.append(Relaxation(key, label, n))
    return out


def explain_fit(cat: Catalogue, row, p: Preferences) -> list:
    """Warnings for the detail view, so a product is never presented as suitable when it is not."""
    notes = []
    if row["price"] > p.budget_max:
        notes.append(f"Over your budget by Rs {int(row['price'] - p.budget_max):,}.")
    if row["price"] < p.budget_min:
        notes.append("Below your minimum budget.")
    if not cat.is_available(row["id"]):
        notes.append("Currently unavailable (simulated stock).")
    elif not cat.eligible_variants(row["id"], row["size_type"], p.sizes, p.excluded_colors):
        notes.append("None of the colours or your size are in stock.")
    if set(row["materials"]) & set(p.excluded_materials):
        notes.append("Contains a material you excluded.")
    return notes
