"""Rule-based outfit stylist: colour harmony + style + occasion + budget + availability.

No weather, trend feed or external AI is used. Season is not modelled."""
from __future__ import annotations

from dataclasses import dataclass, field

from services.product_data import Catalogue, filter_products
from services.recommendation_engine import Preferences

NEUTRALS = {"Black", "White", "Grey", "Navy", "Beige", "Cream", "Brown", "Tan"}
METALS = {"Gold", "Silver", "Rose Gold"}
GOOD_PAIRS = {frozenset(p) for p in [
    ("Navy", "Tan"), ("Olive", "Tan"), ("Olive", "Cream"), ("Olive", "Black"), ("Brown", "Blue"), ("Black", "Red"),
    ("Blue", "Tan"), ("Blue", "White"), ("Burgundy", "Cream"), ("Burgundy", "Navy"), ("Burgundy", "Black"),
    ("Mustard", "Navy"), ("Mustard", "Black"), ("Pink", "Grey"), ("Pink", "Navy"), ("Green", "Cream"),
    ("Green", "Tan"), ("Red", "Navy"), ("Lavender", "Grey"), ("Orange", "Navy"), ("Red", "Cream")]}

TOP = ("Top", ["T-shirts", "Shirts", "Hoodies"])
BOTTOM = ("Bottom", ["Trousers", "Jeans", "Skirts"])
ONEPIECE = ("Dress", ["Dresses", "Ethnic wear"])
OUTER = ("Outerwear", ["Jackets", "Coats"])
SHOES = ("Shoes", ["Sneakers", "Loafers", "Boots", "Formal shoes", "Sandals", "Heels", "Flats", "Running shoes"])
BAG = ("Bag", ["Backpacks", "Handbags", "Totes", "Shoulder bags", "Clutches", "Travel bags"])
WATCH = ("Watch", ["Watches"])
EYE = ("Eyewear", ["Eyewear"])
JEWEL = ("Jewellery", ["Necklaces", "Earrings", "Bracelets", "Rings"])
ACC = ("Accessory", ["Belts", "Caps", "Hats", "Scarves", "Wallets"])

TEMPLATES = {
    "top": [BOTTOM, SHOES, OUTER, BAG], "bottom": [TOP, SHOES, OUTER, ACC], "onepiece": [SHOES, BAG, JEWEL, OUTER],
    "outer": [TOP, BOTTOM, SHOES, ACC], "shoes": [TOP, BOTTOM, BAG, WATCH], "bag": [TOP, BOTTOM, SHOES, WATCH],
    "other": [TOP, BOTTOM, SHOES, BAG],
}
GROUP_OF = {}
for _g, _subs in {"top": TOP[1], "bottom": BOTTOM[1], "onepiece": ONEPIECE[1], "outer": OUTER[1],
                  "shoes": SHOES[1], "bag": BAG[1]}.items():
    for _s in _subs:
        GROUP_OF[_s] = _g
SLOT_OF = {s: name for name, subs in [TOP, BOTTOM, ONEPIECE, OUTER, SHOES, BAG, WATCH, EYE, JEWEL, ACC] for s in subs}
MAX_ITEMS = 5


@dataclass
class OutfitItem:
    slot: str
    id: str
    colour: str = ""


@dataclass
class Outfit:
    items: list = field(default_factory=list)
    total: int = 0
    reasons: list = field(default_factory=list)
    notes: list = field(default_factory=list)
    harmony: float = 0.0

    @property
    def ids(self) -> list:
        return [i.id for i in self.items]


def harmony(a: str, b: str) -> float:
    if a == b:
        return 1.0
    if a in NEUTRALS and b in NEUTRALS:
        return 0.9
    if a in NEUTRALS or b in NEUTRALS:
        return 0.85
    if a in METALS or b in METALS:
        return 0.8
    return 0.85 if frozenset((a, b)) in GOOD_PAIRS else 0.35


def best_colour_pair(cols_a: list, cols_b: list):
    best = (0.0, "", "")
    for a in cols_a:
        for b in cols_b:
            h = harmony(a, b)
            if h > best[0]:
                best = (h, a, b)
    return best


def _jaccard(a, b) -> float:
    a, b = set(a), set(b)
    return len(a & b) / len(a | b) if a | b else 0.0


def _usable_colours(cat: Catalogue, pid: str, row, prefs: Preferences) -> list:
    return [c for c, _ in cat.eligible_variants(pid, row["size_type"], prefs.sizes, prefs.excluded_colors)]


def total_price(cat: Catalogue, ids) -> int:
    return int(sum(r["price"] for r in cat.rows(ids)))


def _candidates(cat: Catalogue, subs: list, prefs: Preferences, exclude: set):
    pool = filter_products(cat, subcategories=subs, sizes=prefs.sizes, excluded_colors=prefs.excluded_colors,
                           excluded_materials=prefs.excluded_materials)
    return pool[~pool["id"].isin(exclude)]


def _rank(cat, cands, anchor, prefs, anchor_cols):
    ranked = []
    for _, r in cands.iterrows():
        cols = _usable_colours(cat, r["id"], r, prefs)
        if not cols:
            continue
        h, _, cc = best_colour_pair(anchor_cols, cols)
        liked_style = _jaccard(r["styles"], prefs.styles) if prefs.styles else 0
        liked_col = 1.0 if set(cols) & set(prefs.colors) else 0
        score = (0.38 * h + 0.24 * _jaccard(r["styles"], anchor["styles"]) + 0.16 * _jaccard(r["occasions"], anchor["occasions"])
                 + 0.10 * liked_style + 0.06 * liked_col + 0.06 * r["trend_score"] / 100)
        ranked.append((score, r["id"], cc))
    return sorted(ranked, key=lambda t: (-t[0], t[1]))


def build_outfit(cat: Catalogue, anchor_id: str, prefs: Preferences | None = None, budget: float | None = None,
                 seed: int = 0) -> Outfit:
    """Anchor + up to 4 compatible pieces. `seed` picks the 1st, 2nd or 3rd best option per slot, which gives
    different style combinations. The total never exceeds `budget` (the anchor alone may, with a note)."""
    prefs = prefs or Preferences()
    anchor = cat.product(anchor_id)
    if anchor is None:
        return Outfit(notes=["That product does not exist, so no outfit can be built."])
    a_cols = _usable_colours(cat, anchor_id, anchor, prefs) or list(anchor["colors"])
    out = Outfit(items=[OutfitItem(SLOT_OF.get(anchor["subcategory"], "Anchor"), anchor_id, a_cols[0] if a_cols else "")])
    total = int(anchor["price"])
    if budget is not None and total > budget:
        out.notes.append("The selected item alone is above your outfit budget.")
    group = GROUP_OF.get(anchor["subcategory"], "other")
    used = {anchor_id}
    used_subs = {anchor["subcategory"]}
    for slot, subs in TEMPLATES[group]:
        if len(out.items) >= MAX_ITEMS:
            break
        cands = _candidates(cat, [s for s in subs if s not in used_subs], prefs, used)
        if budget is not None:
            cands = cands[cands["price"] <= budget - total]
        ranked = _rank(cat, cands, anchor, prefs, a_cols)
        if not ranked:
            out.notes.append(f"No {slot.lower()} fits your budget, size and colour rules.")
            continue
        _, pid, colour = ranked[(seed + len(out.items)) % min(3, len(ranked)) if seed else 0]
        row = cat.product(pid)
        out.items.append(OutfitItem(slot, pid, colour))
        used.add(pid)
        used_subs.add(row["subcategory"])
        total += int(row["price"])
    return finish(cat, out, budget)


def finish(cat: Catalogue, out: Outfit, budget: float | None = None) -> Outfit:
    """Recompute total, harmony and the explanation after any change."""
    rows = cat.rows(out.ids)
    out.total = int(sum(r["price"] for r in rows))
    pairs, cols = [], [i.colour for i in out.items if i.colour]
    for i in range(len(cols)):
        for j in range(i + 1, len(cols)):
            pairs.append(harmony(cols[i], cols[j]))
    out.harmony = round(sum(pairs) / len(pairs), 2) if pairs else 1.0
    reasons = []
    if len(set(cols)) > 1:
        reasons.append(("Colours: " + ", ".join(dict.fromkeys(cols)) + " ") +
                       ("work well together." if out.harmony >= 0.8 else "are a bold mix; consider a neutral swap."))
    elif cols:
        reasons.append(f"A single-colour look in {cols[0]}.")
    if rows:
        common = set.intersection(*[set(r["styles"]) for r in rows]) if len(rows) > 1 else set(rows[0]["styles"])
        shared = max(({s for r in rows for s in r["styles"]}), key=lambda s: sum(s in r["styles"] for r in rows))
        n = sum(shared in r["styles"] for r in rows)
        reasons.append(f"{n} of {len(rows)} pieces share the {shared} style." if not common else
                       "Every piece shares the " + sorted(common)[0] + " style.")
        occ = max(({o for r in rows for o in r["occasions"]}), key=lambda o: sum(o in r["occasions"] for r in rows))
        reasons.append(f"Most pieces suit {occ.lower()} occasions.")
    if budget is not None:
        reasons.append(f"Total Rs {out.total:,} is {'within' if out.total <= budget else 'above'} your Rs {int(budget):,} budget.")
    out.reasons = reasons
    return out


def alternatives(cat: Catalogue, outfit: Outfit, slot: str, prefs: Preferences | None = None, n: int = 4,
                 budget: float | None = None) -> list:
    """Replacement ideas for one slot, best harmony first. The current item is excluded."""
    prefs = prefs or Preferences()
    anchor_id = outfit.items[0].id
    anchor = cat.product(anchor_id)
    subs = next((s for name, s in [TOP, BOTTOM, ONEPIECE, OUTER, SHOES, BAG, WATCH, EYE, JEWEL, ACC] if name == slot), [])
    cands = _candidates(cat, subs, prefs, set(outfit.ids))
    if budget is not None:
        current = next((cat.product(i.id)["price"] for i in outfit.items if i.slot == slot), 0)
        cands = cands[cands["price"] <= budget - outfit.total + current]
    a_cols = _usable_colours(cat, anchor_id, anchor, prefs) or list(anchor["colors"])
    return [pid for _, pid, _ in _rank(cat, cands, anchor, prefs, a_cols)[:n]]


def replace_item(cat: Catalogue, outfit: Outfit, slot: str, new_id: str, budget: float | None = None) -> Outfit:
    row = cat.product(new_id)
    if row is None:
        return outfit
    cols = cat.colours_in_stock(new_id) or list(row["colors"])
    items = [OutfitItem(slot, new_id, cols[0] if cols else "") if i.slot == slot else i for i in outfit.items]
    return finish(cat, Outfit(items=items, notes=list(outfit.notes)), budget)


def add_item(cat: Catalogue, outfit: Outfit, pid: str, budget: float | None = None) -> Outfit:
    row = cat.product(pid)
    if row is None or pid in outfit.ids or len(outfit.items) >= MAX_ITEMS + 1:
        return outfit
    cols = cat.colours_in_stock(pid) or list(row["colors"])
    slot = SLOT_OF.get(row["subcategory"], "Accessory")
    return finish(cat, Outfit(items=outfit.items + [OutfitItem(slot, pid, cols[0] if cols else "")], notes=list(outfit.notes)), budget)


def remove_item(cat: Catalogue, outfit: Outfit, pid: str, budget: float | None = None) -> Outfit:
    if len(outfit.items) <= 1 or pid == outfit.items[0].id:
        return outfit  # the anchor stays
    return finish(cat, Outfit(items=[i for i in outfit.items if i.id != pid], notes=list(outfit.notes)), budget)
