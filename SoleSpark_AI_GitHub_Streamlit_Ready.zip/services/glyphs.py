"""Simple line-art glyphs (64x64 viewBox) used for clearly labelled SAMPLE visuals.

They are drawings, not product photographs. Real photos replace them automatically (see README)."""
from __future__ import annotations

GLYPHS = {
    "shoe": "M6 40 L6 26 Q6 22 10 22 L22 22 L28 30 L50 34 Q58 36 58 44 L58 48 L6 48 Z M6 48 H58",
    "boot": "M14 8 H30 V34 L52 38 Q58 40 58 46 L58 50 H12 Z M12 50 H58",
    "heel": "M10 14 L22 14 L24 34 L54 46 L54 52 L46 52 L22 42 L22 56 L16 56 L12 30 Z",
    "tee": "M22 10 L8 18 L14 30 L22 26 L22 54 L42 54 L42 26 L50 30 L56 18 L42 10 Q32 18 22 10 Z",
    "shirt": "M22 10 L8 18 L14 30 L22 26 L22 54 L42 54 L42 26 L50 30 L56 18 L42 10 L32 18 Z M32 18 V54",
    "trousers": "M20 8 H44 L48 56 H35 L32 26 L29 56 H16 Z",
    "dress": "M26 8 H38 L36 22 L50 56 H14 L28 22 Z",
    "skirt": "M22 12 H42 L54 54 H10 Z M22 12 V18 H42 V12",
    "jacket": "M24 8 L10 16 L12 54 H26 V24 L32 30 L38 24 V54 H52 L54 16 L40 8 L32 16 Z",
    "hoodie": "M22 12 Q32 0 42 12 L56 20 L52 32 L44 28 V54 H20 V28 L12 32 L8 20 Z M26 24 Q32 32 38 24",
    "coat": "M22 8 L8 16 L10 58 H26 V22 L32 28 L38 22 V58 H54 L56 16 L42 8 L32 16 Z",
    "kurta": "M22 8 L10 16 L14 28 L22 24 L20 58 H44 L42 24 L50 28 L54 16 L42 8 Q32 18 22 10 Z",
    "bag": "M12 24 H52 L56 56 H8 Z M22 24 Q22 8 32 8 Q42 8 42 24",
    "backpack": "M18 14 Q18 6 32 6 Q46 6 46 14 V56 H18 Z M24 36 H40 V46 H24 Z",
    "clutch": "M8 22 H56 V48 H8 Z M8 22 L32 38 L56 22",
    "travel": "M10 22 H54 V54 H10 Z M24 22 V14 H40 V22 M10 36 H54",
    "ring": "M32 56 A16 16 0 1 0 32 24 A16 16 0 1 0 32 56 M26 20 L32 8 L38 20 Z",
    "necklace": "M10 12 Q32 58 54 12 M32 46 L28 52 L32 58 L36 52 Z",
    "earring": "M32 6 V16 M32 16 A8 8 0 1 0 32 32 A8 8 0 1 0 32 16 M32 32 V48 L28 56 H36 Z",
    "bracelet": "M12 32 A20 12 0 1 0 52 32 A20 12 0 1 0 12 32 M18 32 A14 7 0 1 0 46 32 A14 7 0 1 0 18 32",
    "watch": "M24 6 H40 L42 18 H22 Z M22 46 H42 L40 58 H24 Z M18 18 H46 V46 H18 Z M32 26 V32 L38 36",
    "glasses": "M6 28 H18 M46 28 H58 M18 22 H30 V36 Q30 42 24 42 H22 Q18 42 18 36 Z M34 22 H46 V36 Q46 42 40 42 H38 Q34 42 34 36 Z M30 28 H34",
    "cap": "M8 40 Q8 14 32 14 Q56 14 56 40 Z M8 40 H60 L56 46 H12",
    "hat": "M18 38 Q18 10 32 10 Q46 10 46 38 M4 42 Q32 52 60 42 Q32 34 4 42",
    "belt": "M4 26 H60 V38 H4 Z M24 22 H40 V42 H24 Z M30 32 H34",
    "scarf": "M14 10 Q32 22 50 10 L54 24 Q32 36 10 24 Z M26 30 L22 56 H34 L36 32",
    "wallet": "M8 18 H56 V50 H8 Z M40 30 H56 V38 H40 Z",
}

SUB_GLYPH = {
    "Sneakers": "shoe", "Running shoes": "shoe", "Formal shoes": "shoe", "Boots": "boot", "Sandals": "shoe",
    "Heels": "heel", "Flats": "shoe", "Loafers": "shoe", "T-shirts": "tee", "Shirts": "shirt",
    "Trousers": "trousers", "Jeans": "trousers", "Dresses": "dress", "Skirts": "skirt", "Jackets": "jacket",
    "Hoodies": "hoodie", "Coats": "coat", "Ethnic wear": "kurta", "Backpacks": "backpack", "Handbags": "bag",
    "Totes": "bag", "Shoulder bags": "bag", "Clutches": "clutch", "Travel bags": "travel", "Necklaces": "necklace",
    "Rings": "ring", "Earrings": "earring", "Bracelets": "bracelet", "Watches": "watch", "Eyewear": "glasses",
    "Belts": "belt", "Caps": "cap", "Hats": "hat", "Scarves": "scarf", "Wallets": "wallet",
}

COLOUR_HEX = {
    "Black": "#1b1b1f", "White": "#f2efe9", "Grey": "#8b8d94", "Navy": "#1d2a4d", "Beige": "#cdb99a",
    "Cream": "#efe3c8", "Brown": "#6b4a32", "Tan": "#b98a56", "Olive": "#6b7040", "Red": "#b3262e",
    "Burgundy": "#6e1f2f", "Blue": "#2f5fa8", "Green": "#2e6b4f", "Pink": "#d98aa0", "Mustard": "#c9962a",
    "Silver": "#b9bcc4", "Gold": "#c9a24a", "Rose Gold": "#c98f85", "Orange": "#d9722a", "Lavender": "#9a8cc4",
}


def svg_for(sub: str, colour: str, label: str = "SAMPLE VISUAL") -> str:
    """Return a standalone SVG string for a sample visual."""
    g = GLYPHS[SUB_GLYPH.get(sub, "bag")]
    c = COLOUR_HEX.get(colour, "#8b8d94")
    return (
        '<svg xmlns="http://www.w3.org/2000/svg" viewBox="0 0 400 500" role="img" aria-label="Sample visual">'
        f'<defs><linearGradient id="g" x1="0" y1="0" x2="1" y2="1"><stop offset="0" stop-color="#17171d"/>'
        f'<stop offset="1" stop-color="{c}" stop-opacity=".55"/></linearGradient></defs>'
        '<rect width="400" height="500" fill="url(#g)"/>'
        f'<g transform="translate(60 100) scale(4.5)" fill="{c}" fill-opacity=".85" stroke="#f2efe9" '
        'stroke-width="1.1" stroke-linejoin="round" stroke-linecap="round">'
        f'<path d="{g}"/></g>'
        f'<text x="24" y="478" font-family="Arial" font-size="13" letter-spacing="3" fill="#f2efe9" '
        f'fill-opacity=".6">{label}</text></svg>'
    )
