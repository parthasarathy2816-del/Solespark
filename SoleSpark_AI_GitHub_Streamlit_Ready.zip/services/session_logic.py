"""Pure helpers for wishlist, comparison, recently viewed and saved outfits (no Streamlit needed)."""
from __future__ import annotations

import json

MAX_COMPARE = 3
MAX_RECENT = 8


def toggle_wishlist(wishlist: list, pid: str) -> list:
    return [p for p in wishlist if p != pid] if pid in wishlist else wishlist + [pid]


def add_to_compare(compare: list, pid: str):
    """Return (new list, message). Never allows more than three products."""
    if pid in compare:
        return [p for p in compare if p != pid], "Removed from comparison."
    if len(compare) >= MAX_COMPARE:
        return compare, f"You can compare up to {MAX_COMPARE} products. Remove one first."
    return compare + [pid], "Added to comparison."


def add_recent(recent: list, pid: str) -> list:
    return ([pid] + [p for p in recent if p != pid])[:MAX_RECENT]


def save_outfit(saved: list, name: str, ids: list, total: int) -> list:
    """Saved outfits are plain dicts so they can be stored as JSON. Duplicate item sets are not saved twice."""
    key = sorted(ids)
    if any(sorted(o["ids"]) == key for o in saved):
        return saved
    return saved + [{"name": name.strip() or f"Look {len(saved) + 1}", "ids": list(ids), "total": int(total)}]


def export_state(wishlist: list, outfits: list, profile: dict) -> str:
    return json.dumps({"wishlist": wishlist, "outfits": outfits, "profile": profile}, indent=2)


def import_state(text: str) -> dict:
    """Parse an exported file; bad input gives empty state instead of an exception."""
    try:
        d = json.loads(text)
        return {"wishlist": [str(x) for x in d.get("wishlist", [])], "outfits": list(d.get("outfits", [])),
                "profile": dict(d.get("profile", {}))}
    except (ValueError, AttributeError, TypeError):
        return {"wishlist": [], "outfits": [], "profile": {}}
