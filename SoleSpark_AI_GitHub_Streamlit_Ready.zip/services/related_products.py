"""Similar, alternative and compatible products. Only available products are suggested."""
from __future__ import annotations

from services.outfit_stylist import build_outfit
from services.product_data import Catalogue


def _unique(ids, exclude, limit):
    seen, out = set(exclude), []
    for i in ids:
        if i not in seen:
            seen.add(i)
            out.append(i)
        if len(out) >= limit:
            break
    return out


def _text(df):
    return (df["subcategory"] + " " + df["styles"].apply(" ".join) + " " + df["occasions"].apply(" ".join)
            + " " + df["materials"].apply(" ".join) + " " + df["colors"].apply(" ".join))


def similar_by_content(cat: Catalogue, pid: str, n: int = 6) -> list:
    """TF-IDF + cosine similarity over product attributes (scikit-learn; falls back to token overlap)."""
    df = cat.products
    if df.empty or pid not in set(df["id"]):
        return []
    text, ids = _text(df), list(df["id"])
    pos = ids.index(pid)
    try:
        from sklearn.feature_extraction.text import TfidfVectorizer
        from sklearn.metrics.pairwise import cosine_similarity
        m = TfidfVectorizer().fit_transform(text)
        sims = cosine_similarity(m[pos], m).ravel()
    except ImportError:
        base = set(text.iloc[pos].split())
        sims = [len(base & set(t.split())) / max(len(base | set(t.split())), 1) for t in text]
    order = sorted(range(len(df)), key=lambda i: (-sims[i], ids[i]))
    return _unique([ids[i] for i in order if cat.is_available(ids[i])], [pid], n)


def related_groups(cat: Catalogue, pid: str, limit: int = 4) -> dict:
    """{group name: [ids]} - never contains the selected product, never repeats an id inside a group."""
    cur = cat.product(pid)
    if cur is None:
        return {}
    df = cat.products
    others = df[(df["id"] != pid) & df["id"].apply(cat.is_available)]
    price = cur["price"]
    same_sub = others[others["subcategory"] == cur["subcategory"]]
    same_cat = others[others["category"] == cur["category"]]
    g = {
        "Similar items": same_sub.sort_values("trend_score", ascending=False)["id"].tolist(),
        "Same style": same_cat[same_cat["styles"].apply(lambda s: bool(set(s) & set(cur["styles"])))]["id"].tolist(),
        "Lower-priced alternatives": same_cat[same_cat["price"] < price].sort_values("price", ascending=False)["id"].tolist(),
        "Premium alternatives": same_cat[same_cat["price"] > price * 1.1].sort_values("price")["id"].tolist(),
        "Compatible from other categories": [i for i in build_outfit(cat, pid).ids[1:]],
    }
    return {name: _unique(ids, [pid], limit) for name, ids in g.items()}


def related_flat(cat: Catalogue, pid: str, n: int = 6):
    """One merged, duplicate-free list. Returns (ids, note)."""
    groups = related_groups(cat, pid, limit=n)
    merged = _unique([i for ids in groups.values() for i in ids], [pid], n)
    note = ""
    if len(merged) < n:
        merged = _unique(merged + similar_by_content(cat, pid, n), [pid], n)
        if merged:
            note = "Few close matches exist, so these are the closest alternatives."
    return merged, note


def recommend_from_likes(cat: Catalogue, liked: list, n: int = 6) -> list:
    """Taste profile: average the TF-IDF vectors of liked products, rank the rest by cosine similarity."""
    df = cat.products
    liked = [i for i in dict.fromkeys(liked) if not df.empty and i in set(df["id"])]
    if not liked:
        return []
    ids = list(df["id"])
    try:
        import numpy as np
        from sklearn.feature_extraction.text import TfidfVectorizer
        from sklearn.metrics.pairwise import cosine_similarity
        m = TfidfVectorizer().fit_transform(_text(df))
        sims = cosine_similarity(np.asarray(m[[ids.index(i) for i in liked]].mean(axis=0)), m).ravel()
        ranked = [ids[i] for i in sorted(range(len(ids)), key=lambda i: (-sims[i], ids[i]))]
    except ImportError:
        ranked = list(df.sort_values("trend_score", ascending=False)["id"])
    return _unique([i for i in ranked if cat.is_available(i)], liked, n)
