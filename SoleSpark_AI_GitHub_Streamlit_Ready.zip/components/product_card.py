"""HTML for product visuals and cards. Every dynamic value is escaped.

Picture order: real photos assets/product_images/<ID>.jpg (+ <ID>_2.jpg, <ID>_3.jpg for a gallery), then an
https URL in the CSV, then a clearly labelled SAMPLE VISUAL drawing. Sample visuals are never presented as photos."""
from __future__ import annotations

import base64
from functools import lru_cache
from html import escape
from pathlib import Path

from services.glyphs import COLOUR_HEX, svg_for
from services.product_data import Catalogue

ROOT = Path(__file__).resolve().parent.parent
IMG_DIR = ROOT / "assets" / "product_images"
PHOTO_EXTS = (".jpg", ".jpeg", ".png", ".webp")
MIME = {".jpg": "image/jpeg", ".jpeg": "image/jpeg", ".png": "image/png", ".webp": "image/webp"}


def real_photos(pid: str) -> list:
    out = []
    for suffix in ("", "_2", "_3"):
        for ext in PHOTO_EXTS:
            p = IMG_DIR / f"{pid}{suffix}{ext}"
            if p.is_file():
                out.append(p)
                break
    return out


def has_real_photo(pid: str) -> bool:
    return bool(real_photos(pid))


@lru_cache(maxsize=512)
def _file_uri(path: str) -> str:
    p = Path(path)
    return f"data:{MIME.get(p.suffix.lower(), 'image/jpeg')};base64," + base64.b64encode(p.read_bytes()).decode()


@lru_cache(maxsize=512)
def sample_uri(sub: str, colour: str) -> str:
    return "data:image/svg+xml;base64," + base64.b64encode(svg_for(sub, colour).encode()).decode()


def photo_uris(row, colour: str | None = None) -> tuple:
    """Return (list of image URIs, is_real_photo)."""
    photos = real_photos(str(row["id"]))
    if photos:
        return [_file_uri(str(p)) for p in photos], True
    img = str(row["image"])
    if img.startswith("https://"):
        return [escape(img, quote=True)], True
    return [sample_uri(row["subcategory"], colour or (row["colors"][0] if row["colors"] else "Grey"))], False


def swatches(colours) -> str:
    return "".join(f'<span class="sw" title="{escape(c)}" style="background:{COLOUR_HEX.get(c, "#888")}"></span>' for c in colours)


def badges_for(row, cat: Catalogue, best: bool = False) -> list:
    out = []
    if not cat.is_available(row["id"]):
        return [("Sold out (sim.)", "x")]
    if best:
        out.append(("Best match", "g"))
    if row["new_rank"] and row["new_rank"] <= 8:
        out.append(("New (sample)", ""))
    if row["trend_score"] >= 92:
        out.append(("Trending", ""))
    return out[:2]


def card_html(row, cat: Catalogue, score: int | None = None, best: bool = False, delay: float = 0, why: str = "") -> str:
    uris, real = photo_uris(row, (cat.colours_in_stock(row["id"]) or [None])[0])
    tag = "" if real else '<span class="sample">Sample visual</span>'
    badges = "".join(f'<span class="badge {c}">{escape(t)}</span>' for t, c in badges_for(row, cat, best))
    ring = (f'<div class="ring" style="--p:{int(score)}" aria-label="Match {int(score)} percent"><span>{int(score)}</span></div>'
            if score is not None else "")
    reason = f'<div class="why">{escape(why)}</div>' if why else ""
    return (
        f'<article class="card reveal{" best" if best else ""}" style="animation-delay:{delay:.2f}s">'
        f'<div class="img"><div class="pic" role="img" aria-label="{escape(str(row["name"]))}" '
        f'style="background-image:url(\'{uris[0]}\')"></div>{tag}<div class="badges">{badges}</div></div>'
        f'<div class="body">{ring}<div class="brand">{escape(row["brand"])} &middot; {escape(row["subcategory"])}</div>'
        f'<div class="name">{escape(row["name"])}</div>'
        f'<div class="price">Rs {int(row["price"]):,}</div><div class="sws">{swatches(cat.colours_in_stock(row["id"]))}</div>{reason}</div></article>'
    )
