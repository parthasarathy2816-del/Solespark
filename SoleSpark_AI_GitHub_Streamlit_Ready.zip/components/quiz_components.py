"""Fashion-profile quiz: skippable steps, conditional size questions, answers kept in session state."""
from __future__ import annotations

import streamlit as st

from services.recommendation_engine import BUDGET_MAX, Preferences

STYLES = ["Streetwear", "Casual", "Minimalist", "Luxury", "Sporty", "Formal", "Traditional", "Vintage"]
VIBES = ["Trending", "Timeless", "Understated", "Bold"]
OCCASIONS = ["Everyday", "Work", "Party", "Wedding", "Date night", "Travel", "Gym", "Outdoor", "College"]
SIZES = {"shoe": ["4", "5", "6", "7", "8", "9", "10", "11"], "apparel": ["XS", "S", "M", "L", "XL", "XXL"],
         "waist": ["28", "30", "32", "34", "36"], "ring": ["6", "7", "8", "9"]}
FITS = ["Slim", "Regular", "Relaxed", "Oversized"]
TITLES = {"cats": "Which categories interest you?", "goal": "What are you creating?", "style": "What is your style?",
          "occasion": "What is the occasion?", "colors": "Colours you love and want to avoid", "budget": "Your budget",
          "materials": "Materials and what you already own", "sizes": "Sizes and fit"}


def default_answers() -> dict:
    return {"categories": [], "goal": "Complete outfit", "styles": [], "vibes": [], "occasions": [], "colors": [],
            "excluded": [], "budget": (0, 8000), "materials": [], "excl_materials": [], "owned": [],
            "sizes": {}, "fits": []}


def steps_for(a: dict) -> list:
    """Footwear/clothing/jewellery sizes are only asked when relevant (jewellery-only users never see shoe sizes)."""
    steps = ["cats", "goal", "style", "occasion", "colors", "budget", "materials"]
    if not a["categories"] or set(a["categories"]) & {"Footwear", "Clothing", "Jewellery"}:
        steps.append("sizes")
    return steps


def size_types_for(a: dict) -> list:
    cats = set(a["categories"]) or {"Footwear", "Clothing", "Jewellery"}
    out = []
    if "Footwear" in cats:
        out.append("shoe")
    if "Clothing" in cats:
        out += ["apparel", "waist"]
    if "Jewellery" in cats:
        out.append("ring")
    return out


def answers_to_prefs(a: dict, liked=(), disliked=()) -> Preferences:
    return Preferences(categories=list(a["categories"]), styles=list(a["styles"]), occasions=list(a["occasions"]),
                       colors=list(a["colors"]), excluded_colors=list(a["excluded"]), materials=list(a["materials"]),
                       excluded_materials=list(a["excl_materials"]), budget_min=a["budget"][0], budget_max=a["budget"][1],
                       sizes={k: v for k, v in a["sizes"].items() if v}, fits=list(a["fits"]), vibes=list(a["vibes"]),
                       liked_ids=list(liked), disliked_ids=list(disliked), owned_subcategories=list(a["owned"]))


def step_errors(key: str, a: dict) -> list:
    if key == "colors" and set(a["colors"]) & set(a["excluded"]):
        return ["A colour cannot be both loved and avoided."]
    if key == "budget" and a["budget"][0] > a["budget"][1]:
        return ["Minimum budget cannot be higher than the maximum."]
    if key == "materials" and set(a["materials"]) & set(a["excl_materials"]):
        return ["A material cannot be both preferred and excluded."]
    return []


def render_step(key: str, a: dict, cat) -> None:
    st.markdown(f"### {TITLES[key]}")
    if key == "cats":
        a["categories"] = st.pills("Choose any (leave empty for everything)", sorted(cat.products["category"].unique()),
                                   selection_mode="multi", default=a["categories"], key="q_cats") or []
    elif key == "goal":
        a["goal"] = st.segmented_control("Goal", ["Complete outfit", "One item"], default=a["goal"], key="q_goal") or a["goal"]
    elif key == "style":
        a["styles"] = st.pills("Style", STYLES, selection_mode="multi", default=a["styles"], key="q_styles") or []
        a["vibes"] = st.pills("Mood", VIBES, selection_mode="multi", default=a["vibes"], key="q_vibes") or []
    elif key == "occasion":
        a["occasions"] = st.pills("Occasion", OCCASIONS, selection_mode="multi", default=a["occasions"], key="q_occ") or []
    elif key == "colors":
        cols = sorted({c for cs in cat.products["colors"] for c in cs})
        a["colors"] = st.multiselect("Colours I love", cols, default=a["colors"], key="q_col")
        a["excluded"] = st.multiselect("Colours to avoid", cols, default=a["excluded"], key="q_exc")
    elif key == "budget":
        a["budget"] = st.slider("Per item, Rs", 0, 20000, a["budget"], step=250, key="q_bud")
    elif key == "materials":
        mats = sorted({m for ms in cat.products["materials"] for m in ms})
        a["materials"] = st.multiselect("Materials I prefer", mats, default=a["materials"], key="q_mat")
        a["excl_materials"] = st.multiselect("Materials to avoid", mats, default=a["excl_materials"], key="q_xmat")
        a["owned"] = st.multiselect("Item types I already own (shown lower in results)", sorted(cat.products["subcategory"].unique()),
                                    default=a["owned"], key="q_owned")
    else:
        labels = {"shoe": "Shoe size (UK/India)", "apparel": "Clothing size", "waist": "Waist (inches)", "ring": "Ring size (India)"}
        for t in size_types_for(a):
            opts = ["Any"] + SIZES[t]
            cur = a["sizes"].get(t, "Any")
            v = st.selectbox(labels[t], opts, index=opts.index(cur) if cur in opts else 0, key=f"q_size_{t}")
            a["sizes"][t] = "" if v == "Any" else v
        if "Clothing" in a["categories"] or not a["categories"]:
            a["fits"] = st.pills("Preferred fit", FITS, selection_mode="multi", default=a["fits"], key="q_fits") or []
