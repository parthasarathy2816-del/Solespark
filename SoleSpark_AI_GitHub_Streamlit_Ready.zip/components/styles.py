"""Design system: editorial dark theme. Static CSS only (no user input is ever inserted)."""

CSS = """
<style>
:root{--ink:#0e0e11;--surface:#17171c;--line:rgba(242,239,233,.14);--ivory:#f2efe9;--muted:#a7a49d;--gold:#c9a24a;--coral:#d9604a}
.stApp{background:radial-gradient(1200px 600px at 85% -10%,rgba(201,162,74,.10),transparent 60%),var(--ink);color:var(--ivory)}
h1,h2,h3{font-family:Georgia,'Times New Roman',serif!important;font-weight:500!important;letter-spacing:-.01em}
.eyebrow{font:600 .72rem/1 Arial,sans-serif;letter-spacing:.28em;text-transform:uppercase;color:var(--gold)}
@keyframes rise{from{opacity:0;transform:translateY(24px)}to{opacity:1;transform:none}}
@keyframes drift{0%,100%{transform:translateY(0) rotate(var(--r,0deg))}50%{transform:translateY(-12px) rotate(var(--r,0deg))}}
@keyframes sweep{from{transform:scaleX(0)}to{transform:scaleX(1)}}
@keyframes intro{0%,65%{opacity:1}100%{opacity:0;visibility:hidden}}
@keyframes shimmer{to{background-position:-200% 0}}
.intro{position:fixed;inset:0;z-index:99999;background:var(--ink);display:grid;place-items:center;pointer-events:none;animation:intro 1.9s ease forwards}
.intro b{font:500 clamp(2rem,6vw,4rem) Georgia,serif;letter-spacing:.04em}.intro i{display:block;height:2px;background:var(--gold);margin-top:.6rem;transform-origin:left;animation:sweep 1.1s ease both}
.hero{display:grid;grid-template-columns:1.1fr .9fr;gap:2rem;align-items:center;padding:2.2rem 0 1.4rem}
.hero h1{font-size:clamp(2.4rem,6.5vw,5rem)!important;line-height:1.02!important;margin:.6rem 0 1rem}
.hero h1 em{color:var(--gold)}
.hero h1 span{display:inline-block;opacity:0;animation:rise .9s cubic-bezier(.2,.7,.2,1) forwards}
.hero p{color:var(--muted);max-width:32rem;font-size:1.05rem;animation:rise 1s .5s both}
.collage{position:relative;height:430px}
.collage .tile{position:absolute;width:48%;aspect-ratio:4/5;background-size:cover;border:1px solid var(--line);box-shadow:0 24px 50px rgba(0,0,0,.5);animation:drift 7s ease-in-out infinite}
.t1{left:0;top:8%;--r:-3deg}.t2{right:2%;top:0;--r:2deg;animation-delay:-2s!important}.t3{left:24%;bottom:0;--r:-1deg;animation-delay:-4s!important}
.grid{display:grid;grid-template-columns:repeat(auto-fill,minmax(210px,1fr));gap:1rem}
.card{background:var(--surface);border:1px solid var(--line);border-radius:4px;overflow:hidden;position:relative;
 transition:transform .35s cubic-bezier(.2,.7,.2,1),border-color .3s,box-shadow .3s;animation:rise .7s both}
.card:hover{transform:translateY(-6px);border-color:rgba(201,162,74,.6);box-shadow:0 18px 40px rgba(0,0,0,.45)}
.card.best{border-color:var(--gold)}
.img{position:relative;aspect-ratio:4/5;overflow:hidden;background:#101014}
.pic{position:absolute;inset:0;background-size:cover;background-position:center;transition:transform .8s cubic-bezier(.2,.7,.2,1)}
.card:hover .pic{transform:scale(1.07)}
.sample{position:absolute;left:8px;bottom:8px;font:600 .62rem Arial;letter-spacing:.14em;text-transform:uppercase;color:var(--ivory);background:rgba(14,14,17,.72);padding:.2rem .45rem}
.badges{position:absolute;left:8px;top:8px;display:flex;gap:4px;flex-wrap:wrap}
.badge{font:700 .62rem Arial;letter-spacing:.1em;text-transform:uppercase;background:var(--ivory);color:var(--ink);padding:.22rem .5rem}
.badge.g{background:var(--gold)}.badge.x{background:var(--coral);color:#fff}
.body{padding:.75rem .85rem .9rem;position:relative}
.brand{font:600 .68rem Arial;letter-spacing:.14em;text-transform:uppercase;color:var(--muted)}
.name{font:500 1.02rem Georgia,serif;margin:.15rem 0}.price{font-weight:700}
.sws{display:flex;gap:5px;margin-top:.4rem}.sw{width:12px;height:12px;border-radius:50%;border:1px solid rgba(255,255,255,.35)}
.why{font-size:.76rem;color:var(--muted);margin-top:.4rem}
.ring{--p:0;position:absolute;right:.7rem;top:.7rem;width:42px;height:42px;border-radius:50%;display:grid;place-items:center;
 background:conic-gradient(var(--gold) calc(var(--p)*1%),rgba(255,255,255,.14) 0)}
.ring span{background:var(--surface);width:32px;height:32px;border-radius:50%;display:grid;place-items:center;font:700 .78rem Arial}
.cat{position:relative;min-height:150px;border:1px solid var(--line);padding:1rem;overflow:hidden;background:var(--surface);transition:.35s}
.cat:hover{border-color:var(--gold);transform:translateY(-4px)}.cat b{font:500 1.3rem Georgia,serif}
.cat::after{content:"";position:absolute;left:1rem;bottom:.8rem;height:2px;width:40%;background:var(--gold);transform:scaleX(0);transform-origin:left;transition:.4s}
.cat:hover::after{transform:scaleX(1)}
.glass{background:rgba(255,255,255,.04);border:1px solid var(--line);padding:1rem 1.2rem;border-radius:4px}
.look{border:1px solid var(--line);padding:.9rem;background:var(--surface);border-radius:4px}
.thumbs{display:flex;gap:6px;margin:.5rem 0}.thumbs .th{width:56px;aspect-ratio:4/5;background-size:cover;border:1px solid var(--line)}
.prog{height:3px;background:var(--line)}.prog div{height:100%;background:var(--gold);transition:width .6s}
.skel{height:300px;background:linear-gradient(90deg,#17171c 25%,#23232a 50%,#17171c 75%);background-size:200% 100%;animation:shimmer 1.2s linear infinite}
.skels{display:grid;grid-template-columns:repeat(auto-fit,minmax(200px,1fr));gap:1rem}
.note{font-size:.8rem;color:var(--muted)}
.chip{display:inline-block;border:1px solid var(--line);padding:.2rem .7rem;margin:0 .3rem .3rem 0;font-size:.8rem}
.footer{margin-top:3rem;padding:1.4rem 0;border-top:1px solid var(--line);color:var(--muted);font-size:.85rem}
.stButton>button{border-radius:2px;border:1px solid var(--line);letter-spacing:.04em;transition:transform .2s,border-color .2s,background .2s}
.stButton>button:hover{border-color:var(--gold);transform:translateY(-2px)}
.stButton>button[kind="primary"]{background:var(--gold);color:#15130d;border:0;font-weight:700}
:focus-visible{outline:2px solid var(--gold)!important;outline-offset:2px}
@supports (animation-timeline:view()){.reveal{animation:rise both;animation-timeline:view();animation-range:entry 0% cover 28%}}
@media (max-width:760px){.hero{grid-template-columns:1fr}.collage{height:320px}.grid{grid-template-columns:repeat(2,1fr);gap:.6rem}.name{font-size:.92rem}}
@media (prefers-reduced-motion:reduce){*,*::before,*::after{animation:none!important;transition:none!important}.intro{display:none}.hero h1 span{opacity:1}}
</style>
"""

SKELETON = '<div class="skels"><div class="skel"></div><div class="skel"></div><div class="skel"></div><div class="skel"></div></div>'
INTRO = '<div class="intro" aria-hidden="true"><div><b>SoleSpark</b><i></i></div></div>'
