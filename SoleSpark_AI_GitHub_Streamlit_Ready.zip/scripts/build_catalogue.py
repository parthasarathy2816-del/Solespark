"""Builds data/products.csv, data/product_variants.csv and the sample visuals in assets/product_images/.

All products, prices, ratings and stock are FICTIONAL demo data. Run:  python scripts/build_catalogue.py
"""
from __future__ import annotations

import csv
import hashlib
import sys
from pathlib import Path

ROOT = Path(__file__).resolve().parent.parent
sys.path.insert(0, str(ROOT))
from services.glyphs import svg_for  # noqa: E402

BRANDS = ["Aurelle", "Northbound", "Kiln & Co", "Vesper", "Mosaic Lane", "Tarn", "Halcyon", "Ember Row"]
SIZES = {"shoe": "4|5|6|7|8|9|10|11", "apparel": "XS|S|M|L|XL|XXL", "waist": "28|30|32|34|36",
         "ring": "6|7|8|9", "free": "Free", "none": ""}
WOMEN, MEN = "", ""

# category, subcategory, size_type, price_lo, price_hi, materials, styles, occasions, colours, fit, care, names
S = [
    ("Footwear", "Sneakers", "shoe", 1999, 5999, "Leather|Canvas|Mesh", "Streetwear|Casual|Sporty|Minimalist", "Everyday|College|Travel", "White|Black|Grey|Navy|Cream|Olive", "", "Wipe clean with a damp cloth; air dry.", ["Court Classic Low", "Retro Runner 90", "Chunky Street Platform", "Canvas Everyday Low"]),
    ("Footwear", "Running shoes", "shoe", 2999, 8999, "Mesh|Knit", "Sporty|Casual", "Gym|Outdoor|Everyday", "Black|Blue|Orange|Grey|Green", "", "Hand wash gently; never machine dry.", ["AeroKnit Daily Trainer", "Tempo Pro Racer", "Cloudform Distance"]),
    ("Footwear", "Formal shoes", "shoe", 3499, 9499, "Leather", "Formal|Luxury|Vintage", "Work|Wedding|Party", "Black|Brown|Tan|Burgundy", "", "Polish with neutral cream; use a shoe tree.", ["Oxford Cap-Toe", "Derby Brogue", "Monk Strap Classic"]),
    ("Footwear", "Boots", "shoe", 3999, 10999, "Suede|Leather", "Vintage|Streetwear|Casual", "Outdoor|Everyday|Date night", "Brown|Black|Tan|Olive", "", "Brush suede; use a protector spray.", ["Chelsea Suede Boot", "Lug-Sole Combat Boot", "Trail Hiker Boot"]),
    ("Footwear", "Sandals", "shoe", 999, 3499, "Leather|Rubber|Woven fabric", "Casual|Minimalist|Sporty", "Everyday|Travel|Outdoor", "Tan|Black|Beige|Brown", "", "Rinse and air dry in shade.", ["Leather Strap Sandal", "Cushion Slide", "Woven Sport Sandal"]),
    ("Footwear", "Heels", "shoe", 2499, 7499, "Satin|Suede|Leather", "Luxury|Formal|Minimalist", "Party|Wedding|Date night", "Black|Red|Beige|Gold|Silver", "", "Spot clean; store in a dust bag.", ["Block Heel Pump", "Stiletto Evening Heel", "Kitten Heel Slingback"]),
    ("Footwear", "Flats", "shoe", 1499, 3999, "Satin|Leather", "Minimalist|Casual|Traditional", "Work|Everyday|Date night", "Black|Beige|Pink|Navy", "", "Spot clean with a soft cloth.", ["Ballet Flat Satin", "Pointed Leather Flat"]),
    ("Footwear", "Loafers", "shoe", 2499, 7999, "Leather|Suede", "Classic|Formal|Luxury|Minimalist", "Work|Everyday|Date night", "Brown|Black|Tan|Navy|Burgundy", "", "Brush and condition leather monthly.", ["Penny Loafer", "Tassel Suede Loafer", "Horsebit Loafer"]),
    ("Clothing", "T-shirts", "apparel", 499, 1999, "Cotton|Cotton blend", "Casual|Streetwear|Minimalist|Sporty", "Everyday|College|Gym", "White|Black|Grey|Navy|Olive|Cream|Red", "Regular|Relaxed|Slim|Oversized", "Machine wash cold; tumble dry low.", ["Essential Cotton Tee", "Oversized Graphic Tee", "Ribbed Slim Tee", "Striped Breton Tee"]),
    ("Clothing", "Shirts", "apparel", 999, 3499, "Cotton|Linen|Flannel", "Formal|Casual|Classic|Minimalist", "Work|Everyday|Date night", "White|Blue|Navy|Beige|Olive|Pink", "Regular|Slim|Relaxed", "Machine wash warm; iron on medium.", ["Oxford Button-Down", "Linen Camp Shirt", "Poplin Formal Shirt", "Flannel Check Shirt"]),
    ("Clothing", "Trousers", "waist", 1299, 4499, "Wool blend|Cotton twill|Linen", "Formal|Casual|Minimalist|Streetwear", "Work|Everyday|Party", "Black|Navy|Beige|Olive|Grey|Brown", "Regular|Slim|Relaxed", "Dry clean or gentle cycle; press with a cloth.", ["Pleated Wool Trouser", "Stretch Chino", "Tapered Cargo Trouser"]),
    ("Clothing", "Jeans", "waist", 1499, 3999, "Denim", "Casual|Streetwear|Vintage", "Everyday|College|Date night", "Blue|Black|Grey|Navy", "Slim|Regular|Relaxed", "Wash inside out in cold water.", ["Straight Indigo Jean", "Black Slim Jean", "Wide-Leg Washed Jean"]),
    ("Clothing", "Dresses", "apparel", 1499, 6999, "Satin|Cotton|Viscose|Crepe", "Luxury|Casual|Minimalist|Vintage", "Party|Date night|Wedding|Everyday", "Black|Red|Burgundy|Pink|Green|Navy|Cream", "Regular|Relaxed", "Hand wash cold; hang dry.", ["Wrap Midi Dress", "Satin Slip Dress", "Floral Tea Dress", "Little Black Dress"]),
    ("Clothing", "Skirts", "apparel", 899, 3499, "Satin|Denim|Pleated crepe", "Minimalist|Casual|Streetwear|Luxury", "Everyday|Party|Work", "Black|Beige|Blue|Olive|Pink", "Regular|Slim", "Gentle machine wash; steam to refresh pleats.", ["Pleated Midi Skirt", "Denim Mini Skirt", "Satin Bias Skirt"]),
    ("Clothing", "Jackets", "apparel", 2499, 7999, "Nylon|Denim|Wool blend", "Streetwear|Formal|Casual|Sporty", "Everyday|Work|Outdoor", "Black|Olive|Navy|Blue|Tan", "Regular|Oversized|Slim", "Spot clean; dry clean for blazers.", ["Bomber Jacket", "Denim Trucker Jacket", "Tailored Blazer"]),
    ("Clothing", "Hoodies", "apparel", 1299, 3999, "Fleece|Cotton blend", "Streetwear|Casual|Sporty", "Everyday|College|Gym", "Grey|Black|Navy|Cream|Olive|Lavender", "Oversized|Regular|Relaxed", "Machine wash cold, inside out.", ["Heavyweight Zip Hoodie", "Pullover Fleece Hoodie", "Cropped Logo Hoodie"]),
    ("Clothing", "Coats", "apparel", 4999, 12999, "Wool|Quilted nylon", "Luxury|Formal|Classic|Minimalist", "Work|Travel|Everyday", "Black|Tan|Navy|Grey", "Regular|Relaxed", "Dry clean only.", ["Wool Overcoat", "Quilted Puffer Coat"]),
    ("Clothing", "Ethnic wear", "apparel", 2499, 14999, "Silk|Cotton|Georgette|Brocade", "Traditional|Luxury", "Wedding|Party|Everyday", "Red|Mustard|Green|Navy|Pink|Cream|Burgundy", "Regular|Relaxed", "Dry clean only; store folded in muslin.", ["Embroidered Cotton Kurta Set", "Silk Banarasi Saree", "Anarkali Festive Gown", "Bandhgala Sherwani Set"]),
    ("Bags", "Backpacks", "none", 1299, 4999, "Nylon|Canvas|Leather", "Casual|Sporty|Minimalist|Streetwear", "College|Travel|Everyday", "Black|Navy|Olive|Grey|Tan", "", "Wipe with a damp cloth.", ["Commuter Roll-Top Backpack", "Campus Daypack", "Trail 30L Rucksack"]),
    ("Bags", "Handbags", "none", 1999, 8999, "Leather|Vegan leather", "Luxury|Classic|Minimalist", "Work|Party|Date night", "Black|Tan|Red|Beige|Burgundy", "", "Condition leather; store stuffed.", ["Structured Leather Satchel", "Quilted Chain Handbag", "Top-Handle Mini Bag"]),
    ("Bags", "Totes", "none", 799, 4499, "Canvas|Leather", "Casual|Minimalist", "Everyday|Work|Travel", "Cream|Black|Navy|Tan", "", "Spot clean; air dry.", ["Canvas Market Tote", "Leather Work Tote"]),
    ("Bags", "Shoulder bags", "none", 1799, 6499, "Suede|Leather|Nylon", "Vintage|Streetwear|Luxury", "Everyday|Date night|Party", "Brown|Black|Cream|Green", "", "Brush suede; avoid water.", ["Crescent Shoulder Bag", "Baguette Suede Bag"]),
    ("Bags", "Clutches", "none", 999, 3999, "Satin|Beaded fabric|Metallic leather", "Luxury|Traditional|Minimalist", "Wedding|Party|Date night", "Gold|Silver|Black|Red|Rose Gold", "", "Store in a dust bag; spot clean.", ["Beaded Evening Clutch", "Metallic Envelope Clutch"]),
    ("Bags", "Travel bags", "none", 2499, 8999, "Nylon|Polycarbonate|Canvas", "Casual|Sporty|Minimalist", "Travel|Outdoor", "Black|Navy|Grey|Olive", "", "Wipe clean; check zips regularly.", ["Weekender Duffel", "Cabin Spinner Trolley"]),
    ("Jewellery", "Necklaces", "none", 799, 6999, "Sterling silver|Gold plated|Freshwater pearl", "Luxury|Classic|Minimalist|Traditional", "Party|Wedding|Date night|Everyday", "Gold|Silver|Cream|Rose Gold", "", "Keep dry; wipe with a soft cloth.", ["Pearl Strand Necklace", "Gold Chain Pendant", "Layered Stone Necklace"]),
    ("Jewellery", "Rings", "ring", 599, 5999, "Sterling silver|Gold plated|Brass", "Minimalist|Streetwear|Luxury", "Everyday|Party|Wedding", "Silver|Gold|Rose Gold", "", "Remove before swimming; polish gently.", ["Solitaire Silver Ring", "Chunky Signet Ring", "Stackable Band Set"]),
    ("Jewellery", "Earrings", "none", 499, 4999, "Gold plated|Sterling silver|Freshwater pearl", "Traditional|Minimalist|Luxury", "Party|Wedding|Everyday", "Gold|Silver|Cream|Rose Gold", "", "Store separately; wipe after use.", ["Gold Hoop Earrings", "Jhumka Drop Earrings", "Pearl Stud Earrings"]),
    ("Jewellery", "Bracelets", "none", 599, 5499, "Sterling silver|Leather|Gold plated", "Minimalist|Streetwear|Luxury|Casual", "Everyday|Party|Date night", "Silver|Gold|Brown|Black", "", "Keep dry; polish with a cloth.", ["Tennis Chain Bracelet", "Leather Wrap Bracelet", "Charm Bangle"]),
    ("Watches", "Watches", "none", 1499, 12999, "Stainless steel|Leather strap|Silicone", "Minimalist|Sporty|Luxury|Classic|Vintage", "Work|Everyday|Gym|Party", "Silver|Black|Rose Gold|Brown|Navy|Green", "", "Avoid deep water unless rated; wipe dry.", ["Minimalist Mesh Watch", "Chronograph Steel Watch", "Digital Sport Watch", "Leather Dress Watch", "Rose Gold Bracelet Watch", "Field Canvas Watch"]),
    ("Eyewear", "Eyewear", "none", 799, 5999, "Metal|Acetate|TR90 plastic", "Classic|Streetwear|Luxury|Sporty|Minimalist", "Everyday|Travel|Outdoor", "Black|Gold|Tan|Silver|Brown|Blue", "", "Clean with the supplied cloth.", ["Aviator Metal Sunglasses", "Wayfarer Acetate Sunglasses", "Round Wire Sunglasses", "Cat-Eye Tinted Sunglasses", "Blue-Light Frames", "Sport Wrap Shades"]),
    ("Accessories", "Belts", "none", 499, 2999, "Leather|Canvas|Woven elastic", "Classic|Casual|Formal|Minimalist", "Work|Everyday", "Black|Brown|Tan|Navy|Olive", "", "Condition leather; avoid soaking.", ["Reversible Leather Belt", "Canvas Web Belt", "Woven Stretch Belt"]),
    ("Accessories", "Caps", "none", 399, 1499, "Cotton|Mesh|Wool blend", "Streetwear|Sporty|Casual", "Everyday|Outdoor|College", "Black|Navy|Olive|White|Red", "", "Spot clean; do not machine wash.", ["Washed Dad Cap", "Mesh Trucker Cap", "Wool Baseball Cap"]),
    ("Accessories", "Hats", "none", 799, 2999, "Wool felt|Straw", "Vintage|Classic|Casual", "Travel|Outdoor|Date night", "Beige|Black|Brown|Tan", "", "Brush gently; keep shape with stuffing.", ["Wool Fedora", "Packable Straw Hat"]),
    ("Accessories", "Scarves", "none", 399, 2499, "Silk|Wool|Cotton", "Classic|Luxury|Traditional|Casual", "Travel|Everyday|Party", "Red|Navy|Cream|Grey|Mustard|Burgundy", "", "Hand wash cold or dry clean (silk).", ["Silk Print Scarf", "Wool Muffler", "Cotton Bandana"]),
    ("Accessories", "Wallets", "none", 499, 2999, "Leather|Vegan leather", "Classic|Minimalist|Luxury", "Everyday|Work|Travel", "Black|Brown|Tan|Navy", "", "Keep away from moisture.", ["Slim Cardholder", "Bifold Leather Wallet", "Zip Travel Wallet"]),
]
PREFIX = {"Footwear": "FT", "Clothing": "CL", "Bags": "BG", "Jewellery": "JW", "Watches": "WT", "Eyewear": "EY", "Accessories": "AC"}


def h(*parts) -> int:
    return int(hashlib.md5("|".join(map(str, parts)).encode()).hexdigest(), 16)


def pick(pool: list, i: int, n: int) -> list:
    return [pool[(i + k) % len(pool)] for k in range(min(n, len(pool)))]


def main() -> None:
    products, variants, counters = [], [], {}
    for cat, sub, st, lo, hi, mats, styles, occs, cols, fits, care, names in S:
        mats, styles, occs, cols = (x.split("|") for x in (mats, styles, occs, cols))
        fits = fits.split("|") if fits else []
        for i, name in enumerate(names):
            counters[cat] = counters.get(cat, 0) + 1
            pid = f"{PREFIX[cat]}{counters[cat]:03d}"
            raw = lo + (hi - lo) * i / max(len(names) - 1, 1)
            price = max(int(round(raw / 100.0)) * 100 - 1, 199)
            my_styles, my_occ = pick(styles, i, 2), pick(occs, i, 2)
            colours, material = pick(cols, i, 3), mats[i % len(mats)]
            timeless = any(s in my_styles for s in ("Luxury", "Formal", "Traditional", "Classic"))
            vibe = ["Timeless", "Understated"][i % 2] if timeless else ["Trending", "Bold"][i % 2]
            row = dict(id=pid, name=name, brand=BRANDS[h(pid) % len(BRANDS)], category=cat, subcategory=sub,
                       price=price, styles="|".join(my_styles), occasions="|".join(my_occ), colors="|".join(colours),
                       materials=material, size_type=st, fit=fits[i % len(fits)] if fits else "", vibe=vibe,
                       description=f"{name} in {material.lower()}: a {my_styles[0].lower()} piece for {my_occ[0].lower()} wear. Sample product.",
                       care=care, rating=round(3.8 + (h(pid, "r") % 11) / 10, 1), trend_score=40 + h(pid, "t") % 59,
                       new_rank=0, image=f"assets/product_images/{pid}.svg")
            products.append(row)
            for c in colours:
                for s in (SIZES[st].split("|") if SIZES[st] else ["One size"]):
                    stock = 0 if h(pid, c, s) % 4 == 0 else 1 + h(pid, c, s, "q") % 9
                    variants.append(dict(variant_id=f"{pid}-{c[:3].upper()}-{s}", product_id=pid, colour=c, size=s, stock=stock))
            first = next(v for v in variants if v["product_id"] == pid)
            if not any(v["stock"] for v in variants if v["product_id"] == pid):
                first["stock"] = 3
    for rank, p in enumerate(sorted(products, key=lambda p: h(p["id"], "n")), 1):
        p["new_rank"] = rank
    (ROOT / "data").mkdir(exist_ok=True)
    for name, rows in (("products", products), ("product_variants", variants)):
        with open(ROOT / "data" / f"{name}.csv", "w", newline="", encoding="utf-8") as f:
            w = csv.DictWriter(f, fieldnames=list(rows[0]))
            w.writeheader()
            w.writerows(rows)
    img = ROOT / "assets" / "product_images"
    for old in img.glob("*.svg"):
        old.unlink()
    for p in products:
        (img / f"{p['id']}.svg").write_text(svg_for(p["subcategory"], p["colors"].split("|")[0]), encoding="utf-8")
    print(len(products), "products,", len(variants), "variants")


if __name__ == "__main__":
    main()
