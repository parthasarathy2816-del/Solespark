"""Turn your real product photos into web-sized files the app picks up automatically.

1. Put photos in the incoming/ folder, named by product ID: P001.png, P002.jpg ... (ID list: data/products.csv)
2. Run:  python scripts/prepare_images.py
3. Optimised files appear in assets/product_images/ and replace the placeholder for that product.
Use photos you own or that carry a free licence (for example Unsplash or Pexels) and keep the credit in the README.
"""
from pathlib import Path

from PIL import Image

ROOT = Path(__file__).resolve().parent.parent
SRC, DST = ROOT / "incoming", ROOT / "assets" / "product_images"
EXTS = {".jpg", ".jpeg", ".png", ".webp"}

for f in sorted(SRC.iterdir()):
    if f.suffix.lower() not in EXTS:
        continue
    img = Image.open(f).convert("RGB")
    img.thumbnail((900, 700))  # keeps pages fast
    out = DST / f"{f.stem.upper()}.jpg"
    img.save(out, quality=82, optimize=True)
    print("saved", out.name)

import csv
ids = [r["id"] for r in csv.DictReader(open(ROOT / "data" / "products.csv", encoding="utf-8"))]
have = {p.stem for p in DST.iterdir() if p.suffix.lower() in EXTS - {".svg"}}
missing = [i for i in ids if i not in have]
print(f"{len(ids) - len(missing)} of {len(ids)} products have a real photo. Missing: {', '.join(missing) or 'none'}")
