# SoleSpark AI - Discover Your Style. Build Your Look.

A final-year project prototype: a Streamlit fashion discovery app covering shoes, clothing, bags, jewellery, watches,
eyewear and accessories, with a style quiz, an explainable recommender and an outfit stylist.

**Honesty notes.** All products, prices, ratings, stock and trend scores are fictional demo data. Recommendations are
rule-based (not a trained AI model). There is no weather data, live trend feed, checkout, payment or login.
Pictures labelled "Sample visual" are drawings, not photographs.

## What changed from the earlier demo
- Catalogue grew from 62 shoe/accessory items to 109 products in 7 categories and 34 subcategories, with a real variant table
  (`data/product_variants.csv`: 1,335 colour x size rows with simulated stock).
- Fixed: excluded-colour logic (a product with another colour in stock is kept; a product whose only stock is in an excluded
  colour is removed), inclusive budget limits, and one shared filter used by shop, recommender and stylist so they always agree.
- Size and colour are checked on the same variant, so a size is never shown as available when that colour/size is sold out.
- New: two-stage recommender, outfit stylist (replace / add / remove, other combinations, saved looks), unified search with
  suggestions, category-aware comparison, personal dashboard, JSON export/import, editorial dark design and motion system.

## Features
Home with intro, hero, categories, curated looks, trending and new arrivals - Shop with category/subcategory/price/colour/
material/size filters, sort and search - Style quiz (skippable, conditional size questions) - Results with match scores and
reasons - Product page with variants, care, size guide, similar / compatible / cheaper / premium products - Stylist -
Wishlist, compare (max 3), recently viewed, saved outfits - My style dashboard (built only from your own session).

## Run locally
```bash
git clone https://github.com/YOUR-USERNAME/solespark-ai.git
cd solespark-ai
python -m venv .venv && source .venv/bin/activate     # Windows: .venv\Scripts\activate
pip install -r requirements.txt
streamlit run app.py
```
Rebuild the sample data any time with `python scripts/build_catalogue.py`.

## HTML demo
`solespark_demo.html` is a standalone browser version (no install). It uses the same data and rules, ported to JavaScript.
It saves your wishlist and outfits in the browser (localStorage) only; they do not sync across devices.
To show real photos in the demo, put files named `images/<ID>.jpg` next to the HTML file.

## Real product photos
Save a licensed or your own photo as `assets/product_images/<ID>.jpg` (add `<ID>_2.jpg`, `<ID>_3.jpg` for a gallery).
The app uses it automatically and removes the "Sample visual" label for that product. Resize a folder of photos with
`python scripts/prepare_images.py` (input in `incoming/`). `python tools/check_images.py` lists products still missing a photo.
Only use photos you own or that have a licence allowing this use, and credit them here.

## Recommendation logic
**Stage A - hard filters:** categories, budget (inclusive), in-stock variants, size, excluded colours and materials.
If nothing is left, the app says why and offers explicit relaxations (ignore size, raise budget 25%, allow excluded colours/
materials). Nothing is relaxed silently.
**Stage B - weighted scoring (editable in `services/recommendation_engine.py`):** style 22, occasion 18, budget 14,
colour 12, material 8, mood 8, fit 6, likes 12 (total 100). Only factors you answered are used, then the score is
normalised to 0-100. Liked items boost similar products, disliked items and owned types lower them.
**Related products** use TF-IDF cosine similarity (scikit-learn). **Stylist** scores colour harmony, shared style, occasion,
trend, your preferences, budget, size and stock.

## Tests
```bash
python -m pytest
```
## GitHub
```bash
git init
git add .
git commit -m "SoleSpark AI fashion platform"
git branch -M main
git remote add origin https://github.com/YOUR-USERNAME/solespark-ai.git
git push -u origin main
```
Replace `YOUR-USERNAME` here and in `REPO_URL` in `app.py`.
## Streamlit Community Cloud
Push to GitHub, open share.streamlit.io, choose the repository, branch `main`, main file `app.py`, then Deploy.
Use Manage app for logs. Common fixes: missing package in requirements.txt, files not committed (`data/`, `assets/`).

## Known limitations
Streamlit cannot do scroll-driven or cursor-following effects reliably, so motion uses CSS only (intro, staggered entrances,
hover zoom, match rings, skeleton loading; scroll reveals use CSS scroll timelines where the browser supports them).
Session data resets when the Streamlit session ends; use Export on My style to keep a copy. Photos are not bundled.
The Streamlit UI could not be run in the build sandbox (packages could not be installed); the services layer and the HTML demo
logic were tested, so please run the app once and report any layout issue.
