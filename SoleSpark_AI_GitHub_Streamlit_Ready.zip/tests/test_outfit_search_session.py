import pytest

from services.compare import compare_rows
from services.outfit_stylist import (add_item, alternatives, best_colour_pair, build_outfit, harmony, remove_item,
                                     replace_item, total_price)
from services.product_search import parse_query, search, suggestions
from services.recommendation_engine import Preferences
from services.related_products import recommend_from_likes, related_flat, related_groups
from services.session_logic import (MAX_COMPARE, add_recent, add_to_compare, import_state, export_state, save_outfit,
                                    toggle_wishlist)


# ---- outfits -------------------------------------------------------------------------------------
@pytest.mark.parametrize("anchor", ["CL001", "CL010", "FT003", "BG004", "WT002", "CL030"])
def test_outfit_is_compatible_and_total_is_correct(catalogue, anchor):
    o = build_outfit(catalogue, anchor, budget=15000)
    assert o.ids[0] == anchor and len(o.ids) == len(set(o.ids)) and len(o.ids) >= 3
    assert o.total == total_price(catalogue, o.ids)
    subs = [catalogue.product(i)["subcategory"] for i in o.ids]
    assert len(subs) == len(set(subs)) and o.reasons


def test_outfit_respects_budget_and_availability(catalogue):
    o = build_outfit(catalogue, "CL001", budget=4000)
    assert o.total <= 4000 or len(o.ids) == 1
    assert all(catalogue.is_available(i) for i in o.ids)


def test_outfit_respects_excluded_colours_and_size(catalogue):
    p = Preferences(excluded_colors=["Black"], sizes={"shoe": "8", "apparel": "M"})
    o = build_outfit(catalogue, "CL001", p, budget=20000)
    for i in o.items[1:]:
        row = catalogue.product(i.id)
        assert i.colour != "Black" and catalogue.eligible_variants(i.id, row["size_type"], p.sizes, ["Black"])


def test_different_seeds_explore_different_looks(catalogue):
    looks = {tuple(build_outfit(catalogue, "CL001", seed=s).ids) for s in range(3)}
    assert len(looks) >= 2


def test_replace_remove_add_keep_total_correct(catalogue):
    o = build_outfit(catalogue, "CL001")
    slot = o.items[1].slot
    alt = alternatives(catalogue, o, slot, n=3)
    assert alt and o.items[1].id not in alt
    o2 = replace_item(catalogue, o, slot, alt[0])
    assert o2.total == total_price(catalogue, o2.ids) and alt[0] in o2.ids
    o3 = remove_item(catalogue, o2, alt[0])
    assert alt[0] not in o3.ids and o3.total == total_price(catalogue, o3.ids)
    assert remove_item(catalogue, o3, "CL001").ids[0] == "CL001"  # anchor cannot be removed
    o4 = add_item(catalogue, o3, "WT001")
    assert "WT001" in o4.ids and o4.total == total_price(catalogue, o4.ids)


def test_unknown_anchor_gives_message(catalogue):
    o = build_outfit(catalogue, "NOPE")
    assert o.ids == [] and o.notes


def test_colour_harmony_rules():
    assert harmony("Navy", "Navy") == 1.0 and harmony("Black", "Red") >= 0.8 and harmony("Red", "Green") < 0.5
    assert best_colour_pair(["Red"], ["Green", "Black"])[2] == "Black"


# ---- search --------------------------------------------------------------------------------------
def test_search_parses_price_colour_and_subcategory(catalogue):
    q = parse_query(catalogue, "black leather loafers under 5k")
    assert q["max_price"] == 5000 and "Black" in q["colors"] and "Loafers" in q["subcategories"] and "Leather" in q["materials"]
    res = search(catalogue, "black leather loafers under 5k")
    assert not res.products.empty and (res.products["price"] <= 5000).all()


def test_search_works_across_categories(catalogue):
    assert set(search(catalogue, "watch").products["category"]) == {"Watches"}
    assert not search(catalogue, "party").products.empty


def test_search_empty_and_no_match(catalogue):
    assert search(catalogue, "   ").message
    res = search(catalogue, "watch under 100")
    assert res.products.empty and res.message


def test_suggestions(catalogue):
    s = suggestions(catalogue, "jea")
    assert "Jeans" in s and suggestions(catalogue, "j") == []


# ---- related / compare ---------------------------------------------------------------------------
def test_related_excludes_selected_and_duplicates(catalogue):
    for pid in ["FT001", "CL020", "BG001", "JW005"]:
        for ids in related_groups(catalogue, pid).values():
            assert pid not in ids and len(ids) == len(set(ids))
        flat, _ = related_flat(catalogue, pid, n=8)
        assert pid not in flat and len(flat) == len(set(flat))


def test_alternatives_are_cheaper_or_premium(catalogue):
    g = related_groups(catalogue, "CL020")
    price = catalogue.product("CL020")["price"]
    assert all(catalogue.product(i)["price"] < price for i in g["Lower-priced alternatives"])
    assert all(catalogue.product(i)["price"] > price for i in g["Premium alternatives"])


def test_taste_recommendations(catalogue):
    recs = recommend_from_likes(catalogue, ["FT001", "FT002"], 5)
    assert recs and not {"FT001", "FT002"} & set(recs) and recommend_from_likes(catalogue, [], 5) == []


def test_compare_is_category_aware(catalogue):
    rows, note = compare_rows(catalogue, ["CL001", "CL002"])
    names = [r[0] for r in rows]
    assert "Sizes in stock" in names and "Fit" in names and not note
    rows, note = compare_rows(catalogue, ["WT001", "FT001"])
    assert "Sizes in stock" not in [r[0] for r in rows]
    rows, note = compare_rows(catalogue, ["CL001", "FT001"])
    assert note and "different sizing" in note
    assert compare_rows(catalogue, [])[0] == []


# ---- session -------------------------------------------------------------------------------------
def test_wishlist_add_remove():
    w = toggle_wishlist([], "A")
    assert w == ["A"] and toggle_wishlist(w, "A") == []


def test_compare_limited_to_three():
    c = []
    for p in "ABC":
        c, _ = add_to_compare(c, p)
    c, msg = add_to_compare(c, "D")
    assert len(c) == MAX_COMPARE and "up to 3" in msg


def test_recent_and_saved_outfits():
    assert add_recent(add_recent(["A"], "B"), "A") == ["A", "B"]
    s = save_outfit([], "Weekend", ["A", "B"], 2500)
    assert save_outfit(s, "Again", ["B", "A"], 2500) == s and s[0]["total"] == 2500


def test_export_import_roundtrip_and_bad_input():
    text = export_state(["A"], [{"name": "x", "ids": ["A"], "total": 1}], {"styles": ["Casual"]})
    assert import_state(text)["wishlist"] == ["A"]
    assert import_state("not json") == {"wishlist": [], "outfits": [], "profile": {}}
