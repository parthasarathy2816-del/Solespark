from services.product_data import filter_products
from services.recommendation_engine import (WEIGHTS, Preferences, apply_relax, check_weights, explain_fit,
                                            recommend, score_product, validate_preferences)


def test_weights_total_100():
    assert check_weights(WEIGHTS) and sum(WEIGHTS.values()) == 100


def test_recommendations_respect_category_and_style(catalogue):
    res = recommend(catalogue, Preferences(categories=["Footwear"], styles=["Sporty"], budget_max=10000))
    assert res.items
    assert all(catalogue.product(r.id)["category"] == "Footwear" for r in res.items)
    assert "Sporty" in " ".join(res.items[0].reasons)


def test_no_over_budget_products(catalogue):
    res = recommend(catalogue, Preferences(budget_min=500, budget_max=2500))
    assert res.items and all(500 <= catalogue.product(r.id)["price"] <= 2500 for r in res.items)


def test_exact_budget_limit_is_included(tiny):
    res = recommend(tiny, Preferences(budget_min=1000, budget_max=1000))
    assert [r.id for r in res.items] == ["A"]


def test_excluded_colour_never_recommended_through_that_colour(catalogue):
    p = Preferences(categories=["Clothing"], excluded_colors=["Black"], budget_max=20000)
    res = recommend(catalogue, p, top_n=50)
    for r in res.items:
        row = catalogue.product(r.id)
        assert catalogue.eligible_variants(r.id, row["size_type"], {}, ["Black"])


def test_unavailable_size_explains_and_offers_relaxation(tiny):
    p = Preferences(categories=["Clothing"], subcategories=["Shirts"], sizes={"apparel": "XXL"}, budget_max=5000)
    res = recommend(tiny, p)
    assert not res.items and "relax" in res.message and any(o.key == "size" for o in res.relaxations)
    assert recommend(tiny, p, relax=["size"]).items


def test_budget_is_never_relaxed_silently(tiny):
    res = recommend(tiny, Preferences(budget_max=500))
    assert not res.items
    assert all(tiny.product(r.id)["price"] <= 500 for r in recommend(tiny, Preferences(budget_max=500)).items)
    assert apply_relax(Preferences(budget_max=1000), ["budget"]).budget_max == 1250


def test_invalid_budget_range(tiny):
    res = recommend(tiny, Preferences(budget_min=5000, budget_max=1000))
    assert res.errors and "Minimum" in res.message
    assert validate_preferences(Preferences(budget_max=0))
    assert validate_preferences(Preferences(colors=["Red"], excluded_colors=["Red"]))


def test_empty_catalogue_is_graceful():
    from services.product_data import make_catalogue
    res = recommend(make_catalogue([], []), Preferences())
    assert not res.items and "empty" in res.message.lower()


def test_scores_are_normalised_0_to_100(catalogue):
    res = recommend(catalogue, Preferences(styles=["Casual", "Luxury"], occasions=["Party"], colors=["Black"],
                                           vibes=["Trending"], fits=["Slim"], budget_max=20000), top_n=100)
    assert res.items and all(0 <= r.score <= 100 for r in res.items)
    assert [r.score for r in res.items] == sorted((r.score for r in res.items), reverse=True)


def test_multicolour_product_scores_on_preferred_colour(tiny):
    row = tiny.product("A")
    hit, why = score_product(tiny, row, Preferences(colors=["Blue"], budget_max=5000))
    miss, _ = score_product(tiny, row, Preferences(colors=["Green"], budget_max=5000))
    assert hit > miss and any("Blue" in w for w in why)


def test_likes_boost_and_dislikes_penalise(catalogue):
    liked = ["CL001"]
    base = Preferences(categories=["Clothing"], budget_max=20000)
    boosted = Preferences(categories=["Clothing"], budget_max=20000, liked_ids=liked)
    r1 = {r.id: r.score for r in recommend(catalogue, base, top_n=100).items}
    r2 = recommend(catalogue, boosted, top_n=100)
    assert "CL001" not in [r.id for r in r2.items]
    assert any("liked" in " ".join(r.reasons) for r in r2.items)
    assert r1


def test_missing_attributes_do_not_crash():
    from services.product_data import make_catalogue
    c = make_catalogue([{"id": "Q", "name": "Q", "price": 900, "category": "Bags"}],
                       [{"product_id": "Q", "colour": "Black", "size": "One size", "stock": 2}])
    res = recommend(c, Preferences(styles=["Casual"], fits=["Slim"], vibes=["Bold"], budget_max=2000))
    assert isinstance(res.items, list)


def test_explain_fit_warns(tiny):
    row = tiny.product("C")
    notes = explain_fit(tiny, row, Preferences(budget_max=2000, sizes={"waist": "28"}))
    assert any("Over your budget" in n for n in notes) and any("in stock" in n for n in notes)


def test_recommend_agrees_with_shop_filter(catalogue):
    p = Preferences(categories=["Footwear"], budget_max=6000, sizes={"shoe": "8"}, excluded_colors=["White"])
    shop = set(filter_products(catalogue, p.categories, (), (p.budget_min, p.budget_max), p.sizes, (), p.excluded_colors)["id"])
    assert {r.id for r in recommend(catalogue, p, top_n=200).items} <= shop


def test_owned_item_types_rank_lower(catalogue):
    base = Preferences(categories=["Footwear"], budget_max=20000)
    owned = Preferences(categories=["Footwear"], budget_max=20000, owned_subcategories=["Sneakers"])
    a = {r.id: r.score for r in recommend(catalogue, base, top_n=100).items}
    b = {r.id: r.score for r in recommend(catalogue, owned, top_n=100).items}
    sneaker = next(i for i in a if catalogue.product(i)["subcategory"] == "Sneakers")
    assert b[sneaker] < a[sneaker]
