import pandas as pd

from services.product_data import (Catalogue, clean_products, filter_products, load_catalogue, make_catalogue,
                                   validate_catalogue)

CATS = {"Footwear", "Clothing", "Bags", "Jewellery", "Watches", "Eyewear", "Accessories"}


def test_catalogue_loads_all_major_categories(catalogue):
    assert set(catalogue.products["category"]) == CATS
    assert len(catalogue.products) >= 100 and catalogue.products["id"].is_unique


def test_catalogue_is_consistent(catalogue):
    assert validate_catalogue(catalogue) == []
    assert (catalogue.products["price"] > 0).all()
    assert (catalogue.variants["stock"] >= 0).all()
    assert set(catalogue.variants["product_id"]) <= set(catalogue.products["id"])


def test_missing_files_give_empty_catalogue(tmp_path):
    c = load_catalogue(tmp_path / "nope.csv", tmp_path / "nope2.csv")
    assert c.empty and filter_products(c, categories=["Clothing"]).empty


def test_missing_optional_columns_do_not_crash():
    df = clean_products(pd.DataFrame([{"id": "X", "name": "Bare", "price": 500}]))
    assert df.iloc[0]["styles"] == [] and df.iloc[0]["fit"] == ""


def test_invalid_rows_are_dropped():
    df = clean_products(pd.DataFrame([{"id": "X", "name": "Free", "price": 0}, {"id": "Y", "name": "NoPrice", "price": "abc"}]))
    assert df.empty


def test_category_filter(catalogue):
    out = filter_products(catalogue, categories=["Watches"])
    assert not out.empty and set(out["category"]) == {"Watches"}


def test_budget_limits_are_inclusive(tiny):
    assert list(filter_products(tiny, price_range=(1000, 2000))["id"]) == ["A", "B"]
    assert list(filter_products(tiny, price_range=(1001, 1999))["id"]) == []


def test_excluded_colour_keeps_multicolour_product_with_other_colour(tiny):
    # A has Blue and Red: excluding Red must keep A (via Blue). B's Black variant has no stock.
    ids = list(filter_products(tiny, excluded_colors=["Red"])["id"])
    assert "A" in ids and "B" not in ids and "C" not in ids


def test_excluding_every_colour_removes_product(tiny):
    assert "A" not in list(filter_products(tiny, excluded_colors=["Red", "Blue"])["id"])


def test_size_and_colour_are_checked_on_the_same_variant(tiny):
    # Size L only exists in Red, so Blue + L must not match even though Blue and L both exist for A.
    assert filter_products(tiny, subcategories=["Shirts"], sizes={"apparel": "L"}, colors=["Blue"]).empty
    assert list(filter_products(tiny, subcategories=["Shirts"], sizes={"apparel": "L"}, colors=["Red"])["id"]) == ["A"]


def test_unavailable_variant_is_not_available(tiny):
    assert tiny.stock_of("B", "Black", "M") == 0 and tiny.colours_in_stock("B") == ["Red"]
    assert tiny.sizes_in_stock("A", "Blue") == ["M"]


def test_product_without_variants_is_unavailable():
    c = make_catalogue([{"id": "Z", "name": "Z", "price": 100}], [])
    assert not c.is_available("Z") and filter_products(c).empty


def test_materials_filters(catalogue):
    out = filter_products(catalogue, materials=["Leather"])
    assert not out.empty and all("Leather" in m for m in out["materials"])
    out2 = filter_products(catalogue, excluded_materials=["Leather"])
    assert all("Leather" not in m for m in out2["materials"])


def test_no_size_items_ignore_size_filter(catalogue):
    out = filter_products(catalogue, categories=["Watches"], sizes={"shoe": "8", "apparel": "M"})
    assert len(out) == len(filter_products(catalogue, categories=["Watches"]))
