import sys
from pathlib import Path

import pytest

sys.path.insert(0, str(Path(__file__).resolve().parent.parent))

from services.product_data import load_catalogue, make_catalogue  # noqa: E402


@pytest.fixture(scope="session")
def catalogue():
    return load_catalogue()


def prod(pid, **kw):
    base = dict(id=pid, name=pid, brand="B", category="Clothing", subcategory="Shirts", price=1000,
                styles="Casual", occasions="Everyday", colors="Blue|Red", materials="Cotton", size_type="apparel",
                fit="Regular", vibe="Timeless", description="d", care="c", rating=4.0, trend_score=50, new_rank=1, image="")
    base.update(kw)
    return base


def var(pid, colour, size, stock=5):
    return dict(variant_id=f"{pid}-{colour}-{size}", product_id=pid, colour=colour, size=size, stock=stock)


@pytest.fixture
def tiny():
    """Three products with known variants so boundary cases are exact."""
    products = [prod("A", price=1000), prod("B", price=2000, colors="Red|Black"),
                prod("C", price=3000, colors="Red", subcategory="Jeans", size_type="waist")]
    variants = [var("A", "Blue", "M"), var("A", "Red", "L"),
                var("B", "Red", "M"), var("B", "Black", "M", 0),
                var("C", "Red", "32")]
    return make_catalogue(products, variants)
