# SoleSpark AI — GitHub and Streamlit deployment

## 1. Upload to GitHub
1. Extract this ZIP file on your computer.
2. Open the extracted `solespark_ai_github_ready` folder.
3. Confirm that `app.py`, `requirements.txt`, `components/`, `services/`, `data/`, and `assets/` are directly inside this folder.
4. Create a new GitHub repository named `solespark-ai`.
5. Upload the **contents** of this folder to the repository (not the enclosing folder).
6. Commit the files to the `main` branch.

The most important point: `app.py` must be in the repository's top-level/root directory.

## 2. Deploy on Streamlit Community Cloud
1. Visit https://share.streamlit.io/ and sign in with GitHub.
2. Choose **Create app**.
3. Select your `solespark-ai` repository and the `main` branch.
4. Set **Main file path** to `app.py`.
5. Click **Deploy**.

## 3. If the app still shows an error
- Open the app's **Manage app** menu and view the logs.
- Confirm that `components/product_card.py` exists in GitHub with the exact spelling and capitalization.
- Confirm that the `components/`, `services/`, `data/`, and `assets/` folders were uploaded.
- In Streamlit Cloud, use **Reboot app** after committing a fix.

## Notes
- Do not upload `.venv/`, passwords, API keys, or `.streamlit/secrets.toml`.
- `requirements.txt` contains the packages needed by the deployed app.
- `.python-version` selects Python 3.11 for a consistent deployment.
- Product, price, stock, and trend information in this project is sample/demo data, as described in the original project README.
