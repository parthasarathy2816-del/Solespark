CORRECT IMAGE FORMAT
- File type: .jpg (also .png or .webp work)
- Size: 800 x 1000 pixels (portrait, 4:5), under 200 KB
- Name: the product ID exactly, e.g. CL007.jpg  (IDs are in data/products.csv)
- Extra gallery photos: CL007_2.jpg, CL007_3.jpg

These files are SAMPLE templates (drawings, marked "SAMPLE - REPLACE WITH REAL PHOTO").
Replace each with your real photo of the same name, then copy it to:
  Streamlit app : assets/product_images/
  HTML demo     : an "images" folder next to solespark_demo.html
