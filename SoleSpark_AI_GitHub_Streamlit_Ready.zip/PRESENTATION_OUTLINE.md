# SoleSpark AI - Presentation Outline

1. Title: SoleSpark AI, a shoe discovery and recommendation prototype
2. Problem: too many shoes, hard to choose by budget, size and use
3. Objective: personalised, explainable shoe suggestions
4. Technology: Python, Streamlit, Pandas, scikit-learn
5. Architecture: UI (app.py, components) -> services (data, recommendation, related) -> CSV catalogue
6. Quiz flow: six steps with validation
7. Recommendation logic: weighted score (25/20/15/15/15/5/5) and hard budget/size filters
8. Related products: six groups plus TF-IDF similarity
9. Demo: quiz, results, detail page, wishlist, compare
10. Testing: pytest scenarios (budget, size, duplicates, empty catalogue, compare limit)
11. Limitations: sample data, session-only wishlist
12. Future work and conclusion
13. Thank you
