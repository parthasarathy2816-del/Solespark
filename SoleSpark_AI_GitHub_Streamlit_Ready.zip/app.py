"""SoleSpark AI - fashion discovery and outfit stylist (Streamlit)."""
# Ensure this repository's root is importable when launched by Streamlit Cloud.
import sys
from pathlib import Path

PROJECT_ROOT = Path(__file__).resolve().parent
if str(PROJECT_ROOT) not in sys.path:
    sys.path.insert(0, str(PROJECT_ROOT))

import time
from collections import Counter
from html import escape

import pandas as pd
import streamlit as st

from components.product_card import card_html, has_real_photo, photo_uris
from components.quiz_components import TITLES, answers_to_prefs, default_answers, render_step, step_errors, steps_for
from components.styles import CSS, INTRO, SKELETON
from services.compare import MAX_COMPARE, compare_rows
from services.outfit_stylist import add_item, alternatives, build_outfit, remove_item, replace_item
from services.product_data import filter_products, load_catalogue
from services.product_search import search, suggestions
from services.recommendation_engine import explain_fit, recommend, score_product
from services.related_products import recommend_from_likes, related_groups
from services.session_logic import (add_recent, add_to_compare, export_state, import_state, save_outfit,
                                    toggle_wishlist)

REPO_URL = "https://github.com/YOUR-USERNAME/solespark-ai"  # replace with your own repository
st.set_page_config(page_title="SoleSpark AI", page_icon="✦", layout="wide")
st.markdown(CSS, unsafe_allow_html=True)


@st.cache_data
def _load():
    return load_catalogue()  # product data only; nothing user-specific is cached


CAT = _load()
S = st.session_state
for k, v in {"page": "home", "step": 0, "answers": default_answers(), "selected": None, "wish": [], "dislikes": [],
             "cmp": [], "recent": [], "outfits": [], "relax": [], "toast": "", "seed": 0, "look_budget": 12000,
             "intro": True, "history": Counter(), "detail_look": None}.items():
    S.setdefault(k, v)
if S.intro:
    st.markdown(INTRO, unsafe_allow_html=True)
    S.intro = False


def go(page, **kw):
    S.page = page
    S.update(kw)


def view(pid):
    S.selected, S.page, S.seed, S.detail_look = pid, "detail", 0, None
    S.recent = add_recent(S.recent, pid)


def wish(pid):
    S.wish = toggle_wishlist(S.wish, pid)


def cmp_(pid):
    S.cmp, S.toast = add_to_compare(S.cmp, pid)


def reset_quiz():
    S.update(step=0, answers=default_answers(), relax=[], page="quiz")
    for k in [k for k in S if k.startswith("q_")]:
        del S[k]


def grid(ids, key, scores=None, whys=None, cols=4, best_first=False):
    rows = CAT.rows(ids)
    if not rows:
        st.info("Nothing to show here yet.")
    for s in range(0, len(rows), cols):
        for i, (c, r) in enumerate(zip(st.columns(cols), rows[s:s + cols])):
            n, pid = s + i, r["id"]
            with c:
                st.markdown(card_html(r, CAT, (scores or {}).get(pid), best_first and n == 0, 0.06 * n,
                                      (whys or {}).get(pid, "")), unsafe_allow_html=True)
                a, b, d = st.columns(3)
                a.button("View", key=f"{key}_v_{pid}", on_click=view, args=(pid,), use_container_width=True)
                b.button("♥" if pid in S.wish else "♡", key=f"{key}_w_{pid}", on_click=wish, args=(pid,), help="Wishlist", use_container_width=True)
                d.button("✓" if pid in S.cmp else "⇄", key=f"{key}_c_{pid}", on_click=cmp_, args=(pid,), help="Compare", use_container_width=True)


prefs = answers_to_prefs(S.answers, S.wish, S.dislikes)
# ---------- header ----------
h = st.columns([1.3, 1, 1, 1, 1, 1, 1])
h[0].markdown("### SoleSpark <span style='color:#c9a24a'>AI</span>", unsafe_allow_html=True)
for c, (label, page) in zip(h[1:], [("Home", "home"), ("Shop", "shop"), ("Style quiz", "quiz"), ("Stylist", "stylist"),
                                    (f"Saved ({len(S.wish)})", "saved"), ("My style", "dash")]):
    c.button(label, key=f"nav_{page}", on_click=go, args=(page,), use_container_width=True)
if S.toast:
    st.toast(S.toast)
    S.toast = ""
if CAT.empty:
    st.error("The catalogue could not be loaded (data/products.csv missing or empty). Run: python scripts/build_catalogue.py")
    st.stop()
st.caption("Demo prototype: all products, prices, ratings and stock are fictional sample data. Recommendations are rule-based, not a trained AI model. Visuals marked 'Sample visual' are drawings, not photographs.")
page = S.page
P = CAT.products

# ---------- HOME ----------
if page == "home":
    new = list(P.sort_values("new_rank").head(3)["id"])
    tiles = "".join(f'<div class="tile t{i + 1}" style="background-image:url(\'{photo_uris(CAT.product(p))[0][0]}\')"></div>' for i, p in enumerate(new))
    words = "".join(f'<span style="animation-delay:{0.12 * i}s">{w}&nbsp;</span>' for i, w in enumerate(["Discover", "your", "<em>style.</em>", "Build", "your", "look."]))
    st.markdown(f'<div class="hero"><div><div class="eyebrow">AI-assisted fashion discovery</div><h1>{words}</h1>'
                f'<p>Shoes, clothing, bags, jewellery, watches and eyewear in one place. Tell us your taste and budget, '
                f'then build complete outfits with an explainable, rule-based stylist.</p></div><div class="collage">{tiles}</div></div>', unsafe_allow_html=True)
    b = st.columns([1, 1, 1, 3])
    b[0].button("Start style quiz", type="primary", on_click=go, args=("quiz",), use_container_width=True)
    b[1].button("Open the stylist", on_click=go, args=("stylist",), use_container_width=True)
    b[2].button("Browse shop", on_click=go, args=("shop",), use_container_width=True)
    st.markdown("#### Shop by category")
    cats = list(P["category"].value_counts().index)
    for c, name in zip(st.columns(len(cats)), cats):
        c.markdown(f'<div class="cat"><div class="eyebrow">{int((P.category == name).sum())} styles</div><b>{escape(name)}</b></div>', unsafe_allow_html=True)
        c.button("Open", key=f"home_cat_{name}", on_click=lambda n=name: go("shop", shop_cat=[n]), use_container_width=True)
    st.markdown("#### Curated looks (sample)")
    for c, anchor in zip(st.columns(3), ["CL001", "FT003", "CL013"]):
        o = build_outfit(CAT, anchor, budget=12000)
        with c:
            th = "".join(f'<div class="th" style="background-image:url(\'{photo_uris(r)[0][0]}\')"></div>' for r in CAT.rows(o.ids))
            st.markdown(f'<div class="look"><div class="eyebrow">{len(o.ids)} pieces</div><div class="thumbs">{th}</div><b>Rs {o.total:,}</b></div>', unsafe_allow_html=True)
            st.button("Style this look", key=f"curated_{anchor}", on_click=go, args=("stylist",), kwargs={"selected": anchor}, use_container_width=True)
    st.markdown("#### Trending (sample trend score)")
    grid(P.sort_values("trend_score", ascending=False).head(4)["id"], "trend")
    st.markdown("#### New arrivals (sample)")
    grid(P.sort_values("new_rank").head(4)["id"], "new")
    if S.wish:
        st.markdown("#### Picked for your taste")
        grid(recommend_from_likes(CAT, S.wish, 4), "taste")

# ---------- SHOP ----------
elif page == "shop":
    st.markdown("## Shop")
    q = st.text_input("Search everything (try: black leather loafers under 5k)", key="shop_q")
    for sg in suggestions(CAT, q) if q and len(q) < 8 else []:
        st.caption(f"Suggestion: {sg}")
    with st.expander("Filters", expanded=True):
        f = st.columns(4)
        cats = f[0].multiselect("Category", sorted(P.category.unique()), default=S.get("shop_cat", []))
        subs = f[1].multiselect("Subcategory", sorted(P[P.category.isin(cats)].subcategory.unique() if cats else P.subcategory.unique()))
        price = f[2].slider("Price (Rs)", 0, 15000, (0, 15000), step=250)
        sort = f[3].selectbox("Sort", ["Relevance", "Price: low to high", "Price: high to low", "Rating", "Newest (sample)"])
        g = st.columns(4)
        cols = g[0].multiselect("Colours", sorted({c for x in P.colors for c in x}))
        xcols = g[1].multiselect("Exclude colours", sorted({c for x in P.colors for c in x}))
        mats = g[2].multiselect("Materials", sorted({c for x in P.materials for c in x}))
        sz = g[3].selectbox("Shoe size", ["Any"] + [str(i) for i in range(4, 12)])
        h2 = st.columns(2)
        apparel = h2[0].selectbox("Clothing size", ["Any", "XS", "S", "M", "L", "XL", "XXL"])
        avail = h2[1].checkbox("In stock only", value=True)
    sizes = {k: v for k, v in {"shoe": sz, "apparel": apparel}.items() if v != "Any"}
    out = filter_products(CAT, cats, subs, price, sizes, cols, xcols, mats, (), (), (), avail)
    if q.strip():
        out = out[out["id"].isin(search(CAT, q, avail).products["id"])]
    key = {"Relevance": ("trend_score", False), "Price: low to high": ("price", True), "Price: high to low": ("price", False),
           "Rating": ("rating", False), "Newest (sample)": ("new_rank", True)}[sort]
    out = out.sort_values(key[0], ascending=key[1])
    st.caption(f"{len(out)} of {len(P)} products")
    if out.empty:
        st.info("No products match. Try removing a filter" + (f" or searching for something broader than '{q}'." if q else "."))
    grid(out["id"], "shop")

# ---------- QUIZ ----------
elif page == "quiz":
    a = S.answers
    steps = steps_for(a)
    S.step = min(S.step, len(steps) - 1)
    key = steps[S.step]
    st.markdown(f'<div class="note">Step {S.step + 1} of {len(steps)} &middot; every step can be skipped</div><div class="prog"><div style="width:{(S.step + 1) / len(steps) * 100:.0f}%"></div></div>', unsafe_allow_html=True)
    render_step(key, a, CAT)
    errs = step_errors(key, a)
    for e in errs:
        st.warning(e)
    c = st.columns(5)
    c[0].button("Back", disabled=S.step == 0, on_click=lambda: S.update(step=S.step - 1), use_container_width=True)
    c[1].button("Reset", on_click=reset_quiz, use_container_width=True)
    if S.step < len(steps) - 1:
        c[2].button("Skip", on_click=lambda: S.update(step=S.step + 1), use_container_width=True)
        c[3].button("Continue", type="primary", disabled=bool(errs), on_click=lambda: S.update(step=S.step + 1), use_container_width=True)
    c[4].button("See my picks", type="primary", disabled=bool(errs), on_click=go, args=("results",), use_container_width=True)

# ---------- RESULTS ----------
elif page == "results":
    ph = st.empty()
    ph.markdown(SKELETON, unsafe_allow_html=True)
    time.sleep(0.4)
    res = recommend(CAT, prefs, relax=S.relax)
    ph.empty()
    st.markdown("## Your style profile")
    st.markdown("".join(f'<span class="chip">{escape(x)}</span>' for x in prefs.styles + prefs.vibes + prefs.occasions + [f"Rs {prefs.budget_min:,}-{prefs.budget_max:,}"]), unsafe_allow_html=True)
    st.caption("Preference-based score from explicit rules. It is not a trained model or a validated prediction.")
    if res.items:
        for r in res.items:
            S.history[CAT.product(r.id)["category"]] += 1
        if S.relax:
            st.warning("You relaxed: " + ", ".join(S.relax) + ".")
        st.success(f"Best match: {CAT.product(res.items[0].id)['name']} ({res.items[0].score}). " + "; ".join(res.items[0].reasons[:3]) + ".")
        grid([r.id for r in res.items], "res", {r.id: r.score for r in res.items}, {r.id: "; ".join(r.reasons[:2]) for r in res.items}, best_first=True)
        st.markdown("### Outfit ideas from your top pick")
        o = build_outfit(CAT, res.items[0].id, prefs, budget=prefs.budget_max * 3 or None)
        st.write(" ".join(o.reasons))
        grid(o.ids, "resfit")
    else:
        st.error(res.message)
        for o in res.relaxations:
            st.button(f"Relax: {o.label} ({o.count} products)", key=f"rx_{o.key}", on_click=lambda k=o.key: S.update(relax=S.relax + [k]))
        st.button("Edit my answers", on_click=go, args=("quiz",))

# ---------- DETAIL ----------
elif page == "detail":
    r = CAT.product(S.selected) if S.selected else None
    if r is None:
        st.info("Pick a product from the shop first.")
        st.button("Go to shop", on_click=go, args=("shop",))
    else:
        pid = r["id"]
        L, R = st.columns([1, 1])
        colour = R.selectbox("Colour", r["colors"], key=f"d_col_{pid}")
        uris, real = photo_uris(r, colour)
        with L:
            st.markdown(f'<div class="card"><div class="img"><div class="pic" role="img" aria-label="{escape(r["name"])}" style="background-image:url(\'{uris[0]}\')"></div>'
                        f'{"" if real else "<span class=sample>Sample visual - not a photograph</span>"}</div></div>', unsafe_allow_html=True)
            if len(uris) > 1:
                st.image(uris[1:], width=90)
        with R:
            st.markdown(f"## {r['name']}")
            st.markdown(f"**{r['brand']}** (fictional) &middot; {r['category']} / {r['subcategory']}")
            st.markdown(f"### Rs {int(r['price']):,}")
            st.write(r["description"])
            st.write(f"**Material:** {', '.join(r['materials'])}  \n**Care:** {r['care']}  \n**Rating:** {r['rating']} (sample)")
            in_stock = CAT.sizes_in_stock(pid, colour)
            all_sizes = sorted({z for c_, z, _ in CAT.variants_of(pid) if c_ == colour}, key=lambda z: (len(z), z))
            if r["size_type"] in ("none", "free", ""):
                st.write("**Size:** one size." + ("" if in_stock else " Out of stock in this colour (simulated)."))
            else:
                size = st.radio("Size", all_sizes, horizontal=True, key=f"d_size_{pid}_{colour}",
                                format_func=lambda z: z if z in in_stock else f"{z} (sold out)")
                n = CAT.stock_of(pid, colour, size)
                (st.success if n else st.error)(f"{colour} / {size}: " + (f"{n} left (simulated)" if n else "unavailable in this variant"))
                if r["size_type"] == "shoe":
                    st.caption("Size guide: UK/India sizing. If between sizes, go one up.")
                elif r["size_type"] == "apparel":
                    st.caption(f"Fit: {r['fit'] or 'regular'}. Check the size chart before buying real items.")
            if S.answers["categories"] or S.answers["styles"]:
                notes = explain_fit(CAT, r, prefs)
                if notes:
                    st.warning(" ".join(notes))
                else:
                    sc, why = score_product(CAT, r, prefs)
                    st.success(f"Match {sc}: " + "; ".join(why[:3]))
            b = st.columns(3)
            b[0].button("Remove from wishlist" if pid in S.wish else "Add to wishlist", on_click=wish, args=(pid,), use_container_width=True)
            b[1].button("Remove from compare" if pid in S.cmp else "Compare", on_click=cmp_, args=(pid,), use_container_width=True)
            b[2].button("Style an outfit", on_click=go, args=("stylist",), kwargs={"selected": pid}, use_container_width=True)
        g = related_groups(CAT, pid, 4)
        for title in ["Similar items", "Compatible from other categories", "Lower-priced alternatives", "Premium alternatives"]:
            if g.get(title):
                st.markdown(f"### {title}")
                grid(g[title], f"rel_{title[:4]}")

# ---------- STYLIST ----------
elif page == "stylist":
    st.markdown("## AI outfit stylist")
    st.caption("Rule-based: colour harmony, shared style, occasion, budget, size and stock. No weather or live trend data is used.")
    names = {r["id"]: f"{r['name']} ({r['subcategory']})" for _, r in P.iterrows()}
    ids = list(names)
    anchor = st.selectbox("Anchor item", ids, index=ids.index(S.selected) if S.selected in ids else ids.index("CL001"), format_func=names.get, key="st_anchor")
    S.look_budget = st.slider("Outfit budget (Rs)", 1000, 40000, S.look_budget, step=500, key="st_budget")
    if st.session_state.get("st_last") != (anchor, S.seed):
        S.detail_look = build_outfit(CAT, anchor, prefs, S.look_budget, S.seed)
        st.session_state["st_last"] = (anchor, S.seed)
    o = S.detail_look
    c = st.columns(3)
    c[0].button("Show another combination", on_click=lambda: S.update(seed=S.seed + 1), use_container_width=True)
    c[1].button("Rebuild with this budget", on_click=lambda: S.update(detail_look=build_outfit(CAT, anchor, prefs, S.look_budget, S.seed)), use_container_width=True)
    name = c[2].text_input("Name this look", "My look", key="st_name")
    st.markdown(f"### Total: Rs {o.total:,} &middot; harmony {int(o.harmony * 100)}%")
    for rs in o.reasons + o.notes:
        st.write("• " + rs)
    for it in o.items:
        row = CAT.product(it.id)
        with st.container(border=True):
            cc = st.columns([1, 3, 1, 1, 1])
            cc[0].image(photo_uris(row, it.colour)[0][0], width=70)
            cc[1].markdown(f"**{it.slot}: {row['name']}**  \n{it.colour} · Rs {int(row['price']):,}")
            cc[2].button("♥" if it.id in S.wish else "♡", key=f"sl_w_{it.id}", on_click=wish, args=(it.id,))
            if it.id != anchor:
                cc[3].button("Remove", key=f"sl_r_{it.id}", on_click=lambda i=it.id: S.update(detail_look=remove_item(CAT, S.detail_look, i, S.look_budget)))
            alts = alternatives(CAT, o, it.slot, prefs, 3, S.look_budget)
            if alts and it.id != anchor:
                pick = cc[4].selectbox("Swap", ["-"] + alts, key=f"sl_s_{it.id}", format_func=lambda x: "Swap..." if x == "-" else CAT.product(x)["name"], label_visibility="collapsed")
                if pick != "-":
                    S.detail_look = replace_item(CAT, o, it.slot, pick, S.look_budget)
                    st.rerun()
    add = st.selectbox("Add another item", ["-"] + [i for i in ids if i not in o.ids], format_func=lambda x: "Choose..." if x == "-" else names[x])
    if add != "-":
        S.detail_look = add_item(CAT, o, add, S.look_budget)
        st.rerun()
    s = st.columns(2)
    s[0].button("Save this outfit", type="primary", on_click=lambda: S.update(outfits=save_outfit(S.outfits, name, o.ids, o.total), toast="Outfit saved"), use_container_width=True)
    s[1].button("Save all pieces to wishlist", on_click=lambda: S.update(wish=list(dict.fromkeys(S.wish + o.ids))), use_container_width=True)

# ---------- SAVED ----------
elif page == "saved":
    st.markdown("## Wishlist")
    st.caption("Kept for this browser session only. Use Export on My style to keep a copy.")
    grid(S.wish, "wish") if S.wish else st.info("Your wishlist is empty. Tap ♡ on any product.")
    st.markdown("## Saved outfits")
    for i, ou in enumerate(S.outfits):
        st.write(f"**{ou['name']}** - Rs {ou['total']:,} - " + ", ".join(CAT.product(x)["name"] for x in ou["ids"] if CAT.product(x) is not None))
    if not S.outfits:
        st.info("No saved outfits yet. Build one in the Stylist.")
    st.markdown(f"## Compare (up to {MAX_COMPARE})")
    rows, note = compare_rows(CAT, S.cmp)
    if rows:
        names = [CAT.product(i)["name"] for i in S.cmp]
        st.dataframe(pd.DataFrame({n: [v[j] for _, v in rows] for j, n in enumerate(names)}, index=[a for a, _ in rows]), use_container_width=True)
        if note:
            st.caption(note)
    else:
        st.info(note)
    st.button("Clear wishlist and comparison", on_click=lambda: S.update(wish=[], cmp=[]))

# ---------- DASHBOARD ----------
elif page == "dash":
    st.markdown("## My style")
    st.caption("Everything here comes from your own activity in this session. No other users exist in this demo.")
    if S.answers["styles"] or S.answers["categories"]:
        st.write("**Profile:** " + ", ".join(S.answers["styles"] + S.answers["vibes"] + S.answers["occasions"] + S.answers["categories"]))
    else:
        st.info("Take the style quiz to build your profile.")
    st.button("Edit preferences", on_click=go, args=("quiz",))
    if S.wish:
        st.bar_chart(P[P.id.isin(S.wish)]["category"].value_counts())
    if S.history:
        st.markdown("**Recommendation history (categories recommended this session)**")
        st.bar_chart(pd.Series(dict(S.history)))
    if S.recent:
        st.markdown("### Recently viewed")
        grid(S.recent[:4], "recent")
    st.download_button("Export wishlist and outfits (JSON)", export_state(S.wish, S.outfits, S.answers), "solespark_state.json")
    up = st.file_uploader("Import a saved file", type="json")
    if up is not None:
        d = import_state(up.read().decode("utf-8", "ignore"))
        S.wish, S.outfits = d["wishlist"], d["outfits"]
        st.success("Imported.")

st.markdown(f'<div class="footer">SoleSpark AI &middot; final-year project prototype &middot; fictional sample data &middot; <a href="{REPO_URL}">GitHub</a></div>', unsafe_allow_html=True)
